package com.fdc.billingws.db;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;

import com.fdc.billingws.dto.SalesInvoiceDetails;
import com.fdc.billingws.dto.SalesInvoiceMaster;

@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)
public interface SalesInvoiceDao {

	@SqlUpdate("INSERT INTO tblSalesInvoiceMaster (siNo,siDate,dueDate,partyId,address,panNo,remarks,totalAmount,disRate,"
			+ "disAmount,taxableAmount,taxRate,taxAmount,netAmount,printCount,canceled,userId,entryDate) "
            + "VALUES (:siNo,:siDate,:dueDate,:partyId,:address,:panNo,:remarks,:totalAmount,:disRate,:disAmount,"
            + ":taxableAmount,:taxRate,:taxAmount,:netAmount,:printCount,:canceled,:userId,:entryDate)")
	@GetGeneratedKeys
	public Integer addSalesInvoiceMaster(@BindBean SalesInvoiceMaster salesInvoiceMaster);
	
	@SqlUpdate("UPDATE tblSalesInvoiceMaster SET siNo = :siNo,siDate=:siDate,dueDate=:dueDate,partyId=:partyId,address=:address,"
			+ "panNo=:panNo,remarks=:remarks,totalAmount=:totalAmount,disRate=:disRate,disAmount=:disAmount,taxableAmount=:taxableAmount,"
			+ "taxRate=:taxRate,taxAmount=:taxAmount,netAmount=:netAmount,printCount=:printCount,canceled=:canceled,userId=:userId,"
			+ "entryDate=:entryDate"
			+  " WHERE siId = :siId")
	public void updateSalesInvoiceMaster(@BindBean SalesInvoiceMaster salesInvoiceMaster);
	
	@SqlUpdate("DELETE FROM tblSalesInvoiceMaster WHERE siId = :siId")
	public void deleteSalesInvoiceMaster(@Bind("siId") Integer siId);
	
	@SqlQuery
	@Mapper(SalesInvoiceMasterMapper.class)
	public List<SalesInvoiceMaster> getSalesInvoiceMaster(@Define("query") String query);   
	
	
	@SqlUpdate("INSERT INTO tblSalesInvoiceDetails (siId,sno,itemId,qty,uId,rate,amount,narration) "
            + "VALUES (:siId,:sno,:itemId,:qty,:uId,:rate,:amount,:narration)")
	public void addSalesInvoiceDetails(@BindBean SalesInvoiceDetails salesInvoiceDetails);
	
	@SqlUpdate("UPDATE tblSalesInvoiceDetails SET itemId=:itemId,qty=:qty,uId=:uId,rate=:rate,amount=:amount,narration=:narration"
			+  " WHERE siId = :siNo AND sno = :sno")
	public void updateSalesInvoiceDetails(@BindBean SalesInvoiceDetails salesInvoiceDetails);
	
	@SqlUpdate("DELETE FROM tblSalesInvoiceDetails WHERE siId = :siId")
	public void deleteSalesInvoiceDetails(@Bind("siId") Integer siId);
	
	@SqlQuery
	@Mapper(SalesInvoiceDetailsMapper.class)
	public List<SalesInvoiceDetails> getSalesInvoiceDetails(@Define("query") String query);   
	
}
