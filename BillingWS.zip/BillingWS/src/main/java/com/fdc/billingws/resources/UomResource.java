package com.fdc.billingws.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Response;
import com.fdc.billingws.dto.Uom;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.IUomService;
import com.google.common.base.Optional;

@Path("/billingws/Uom")
@Produces(MediaType.APPLICATION_JSON)
public class UomResource {
	
	final static Logger logger = Logger.getLogger(UomResource.class);

	IUomService uomService = null;

	public UomResource(IUomService uomService) {
		this.uomService = uomService;
	}
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addUserGroup(Uom uom){
        try {		
        	String query;
    		if (uom.getAlias() == null || uom.getAlias().length()==0 ){
    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != uom.getAlias() && uom.getAlias().length() > 0){    			
    			query="SELECT * FROM tblUom WHERE alias = '" + uom.getAlias() + "'";
    			if (uomService.getUom(query).size() > 0){
    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
    			}
    		}
    		if (uom.getName() == null || uom.getName().length()==0 ){
    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != uom.getName() && uom.getName().length() > 0){
    			query="SELECT * FROM tblUom WHERE name = '" + uom.getName() + "'";
    			if (uomService.getUom(query).size() > 0){
    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
    			}
    		}
    		uomService.addUom(uom);
        	return Response.ok(Status.SUCCESS.getStatus(), uom, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> updateUom(@PathParam("id") Integer id,Uom uom){
        try {			
	        	String query;
	    		if (uom.getAlias() == null || uom.getAlias().length()==0 ){
	    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != uom.getAlias() && uom.getAlias().length() > 0){
	    			query="SELECT * FROM tblUom WHERE alias = '" + uom.getAlias() + "' AND id <> " + id;
	    			if (uomService.getUom(query).size() > 0){
	    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
	    			}
	    		}
	    		if (uom.getName() == null || uom.getName().length()==0 ){
	    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != uom.getName() && uom.getName().length() > 0){
	    			query="SELECT * FROM tblUom WHERE name = '" + uom.getName() + "' AND id <> " + id;
	    			if (uomService.getUom(query).size() > 0){
	    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
	    			}
	    		}			
	    		uom.setId(id);
	    		uomService.updateUom(uom);
                return Response.ok(Status.SUCCESS.getStatus(), uom, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
                logger.info(e.getMessage());
                return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    @Path("/{id}")
    public Response<?> deleteUom(@PathParam("id") Integer id){
        try {			
        	uomService.deleteUom(id);
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getUOM(@QueryParam("id") Optional<Integer> id,
				              @QueryParam("alias") Optional<String> alias,
				              @QueryParam("name") Optional<String> name,
				              @QueryParam("orderBy") Optional<String> orderBy,
				              @QueryParam("pageNo") Optional<Integer> pageNo,
				              @QueryParam("rowCount") Optional<Integer> rowCount){
    	try{
    		Double endNo = 0d;
			Integer currentNo = 0;
			
    		List<Uom> listUom = new ArrayList<Uom>();
			String query="";
			String inQuery = "SELECT * FROM tblUom WHERE id IS NOT NULL";
			if(id.isPresent())
				inQuery = inQuery + " AND id = " + id.get();
			if(alias.isPresent())
				inQuery = inQuery + " AND alias = '" + alias.get() + "'";
			if(name.isPresent())
				inQuery = inQuery + " AND name = '" + name.get() + "'";
			
			if (orderBy.isPresent() && pageNo.isPresent() && rowCount.isPresent()){
				query = "SELECT * FROM ( SELECT * , ROW_NUMBER() OVER (ORDER BY " + orderBy.get() + ") AS row FROM (";
				query = query + inQuery + ") AS IT ) AS OT "
						+ "WHERE row >= " + (1 + ((pageNo.get()-1) * rowCount.get())) + " AND  row <= " + (pageNo.get() * rowCount.get());
				
				endNo = Double.valueOf(uomService.getCount(inQuery));
				endNo = Math.ceil(endNo / rowCount.get());
				currentNo = pageNo.get();				
			}else{
				query = inQuery;
				if (orderBy.isPresent()) {
					query = query + " ORDER BY " + orderBy.get();
				}
			}
			listUom.addAll(uomService.getUom(query));
//			return Response.ok(Status.SUCCESS.getStatus(), listUom, Messages.SUCCESS.getMessage());
			return Response.ok(Status.SUCCESS.getStatus(), listUom, Messages.SUCCESS.getMessage(), currentNo, endNo.intValue());
		} catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
		}
    }
	
}
