package com.fdc.billingws.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Item;
import com.fdc.billingws.dto.Response;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.IItemService;
import com.google.common.base.Optional;

@Path("/billingws/Item")
@Produces(MediaType.APPLICATION_JSON)
public class ItemResource {
	final static Logger logger = Logger.getLogger(Item.class);
	
	IItemService itemService = null;
			
    public ItemResource(IItemService itemService) {
		this.itemService = itemService;
	}

	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addItem(Item item){
        try {			
        	String query;
    		if (item.getAlias() == null || item.getAlias().length()==0 ){
    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != item.getAlias() && item.getAlias().length() > 0){
    			query="SELECT * FROM tblItem AS i WHERE i.alias = '" + item.getAlias() + "'";
    			if (itemService.getItem(query).size() > 0){
    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
    			}
    		}
    		if (item.getName() == null || item.getName().length()==0 ){
    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != item.getName() && item.getName().length() > 0){
    			query="SELECT * FROM tblItem AS i WHERE i.name = '" + item.getName() + "'";
    			if (itemService.getItem(query).size() > 0){
    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
    			}
    		}
        	itemService.addItem(item);
        	if (null != item.getuId())
        	{
        		if(null != itemService.getUom(item.getuId())) {
        			item.setUom(itemService.getUom(item.getuId()));	
        		}        		
        	}
        	return Response.ok(Status.SUCCESS.getStatus(), item, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@PUT
	@Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> updateItem(@PathParam("id") Integer id,Item item){
        try {			
        	String query;
    		if (item.getAlias() == null || item.getAlias().length()==0 ){
    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != item.getAlias() && item.getAlias().length() > 0){
    			query="SELECT * FROM tblItem AS i WHERE i.alias = '" + item.getAlias() + "' AND i.id <> " + id;
    			if (itemService.getItem(query).size() > 0){
    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
    			}
    		}
    		if (item.getName() == null || item.getName().length()==0 ){
    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != item.getName() && item.getName().length() > 0){
    			query="SELECT * FROM tblItem AS i WHERE i.name = '" + item.getName() + "' AND i.id <> " + id;
    			if (itemService.getItem(query).size() > 0){
    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
    			}
    		}			
        	item.setId(id);
        	itemService.updateItem(item);
        	if (null != item.getuId())
        	{
        		if(null != itemService.getUom(item.getuId())) {
        			item.setUom(itemService.getUom(item.getuId()));	
        		}        		
        	}
        	return Response.ok(Status.SUCCESS.getStatus(), item, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    @Path("/{id}")
    public Response<?> deleteItem(@PathParam("id") Integer id){
        try {			
			itemService.deleteItem(id);
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getItem(@QueryParam("id") Optional<Integer> id,
					    	   @QueryParam("aliasLike") Optional<String> aliasLike,
							   @QueryParam("alias") Optional<String> alias,
					           @QueryParam("name") Optional<String> name,
					           @QueryParam("nameLike") Optional<String> nameLike,
					    	   @QueryParam("orderBy") Optional<String> orderBy,
				               @QueryParam("pageNo") Optional<Integer> pageNo,
				               @QueryParam("rowCount") Optional<Integer> rowCount){
        try{
        	Double endNo = 0d;
			Integer currentNo = 0;
			
        	List<Item> listItem = new ArrayList<Item>();
        	
        	String query="";
			String inQuery = "SELECT i.id,i.name,i.alias,u.id as uId,u.name as uName,u.alias AS uAlias,u.remarks AS uRemarks,"
						   + "buyingRate,sellingRate,i.remarks FROM tblItem AS i LEFT OUTER JOIN tblUom AS u ON i.uId = u.Id  "
						   + "WHERE i.id IS NOT NULL";
			if(id.isPresent())
				inQuery = inQuery + " AND i.id = " + id.get();
			if(aliasLike.isPresent())
				inQuery = inQuery + " AND i.alias LIKE '" + aliasLike.get() + "%'";
			if(alias.isPresent())
				inQuery = inQuery + " AND i.alias = '" + alias.get() + "'";
			if(nameLike.isPresent())
				inQuery = inQuery + " AND i.name LIKE '" + nameLike.get() + "%'";
			if(name.isPresent())
				inQuery = inQuery + " AND i.name = '" + name.get() + "'";		
			
			if (orderBy.isPresent() && pageNo.isPresent() && rowCount.isPresent()){
				query = "SELECT * FROM ( SELECT * , ROW_NUMBER() OVER (ORDER BY " + orderBy.get() + ") AS row FROM (";
				query = query + inQuery + ") AS IT ) AS OT "
						+ "WHERE row >= " + (1 + ((pageNo.get()-1) * rowCount.get())) + " AND  row <= " + (pageNo.get() * rowCount.get());
				
				endNo = Double.valueOf(itemService.getCount(inQuery));
				endNo = Math.ceil(endNo / rowCount.get());
				currentNo = pageNo.get();				
			}else{
				query = inQuery;
				if (orderBy.isPresent()) {
					query = query + " ORDER BY " + orderBy.get();
				}
			}
			listItem.addAll(itemService.getItem(query));
			return Response.ok(Status.SUCCESS.getStatus(), listItem, Messages.SUCCESS.getMessage(), currentNo,endNo.intValue());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }
    }
}
