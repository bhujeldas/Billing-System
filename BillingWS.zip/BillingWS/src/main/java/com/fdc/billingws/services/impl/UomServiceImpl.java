/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fdc.billingws.services.impl;

import com.fdc.billingws.db.UomDao;
import com.fdc.billingws.dto.Uom;
import com.fdc.billingws.services.IBillingWS;
import java.util.List;
import com.fdc.billingws.services.IUomService;

public class UomServiceImpl implements IUomService{

    IBillingWS billingWS = null;
    
    public UomServiceImpl(IBillingWS billingWS) {
        this.billingWS = billingWS;
    }

    public Uom addUom(Uom uom) {
        UomDao dao = billingWS.getDao(UomDao.class);
        Integer id = dao.addUOM(uom);
        uom.setId(id);
        return uom;        
    }

    public Uom updateUom(Uom uom) {
        UomDao dao = billingWS.getDao(UomDao.class);
        dao.updateUOM(uom);
        return uom;
    }

    public void deleteUom(Integer id) {
        UomDao dao = billingWS.getDao(UomDao.class);
        dao.deleteUOM(id);
    }

    public List<Uom> getUom(String query) {
        UomDao dao = billingWS.getDao(UomDao.class);
        List<Uom> listUom = dao.getUOM(query);
        return listUom;
    }

	public Integer getCount(String query) {
		UomDao dao = billingWS.getDao(UomDao.class);
        Integer count = dao.getCount(query);
        return count;
	}
    
}
