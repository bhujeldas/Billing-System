package com.fdc.billingws.application;

import org.skife.jdbi.v2.DBI;

import com.fdc.billingws.configuration.BillingWSConfiguration;
import com.fdc.billingws.resources.ItemResource;
import com.fdc.billingws.resources.OrganizationResource;
import com.fdc.billingws.resources.PartyResource;
import com.fdc.billingws.resources.SalesInvoiceResource;
import com.fdc.billingws.resources.SettingResource;
import com.fdc.billingws.resources.UomResource;
import com.fdc.billingws.resources.UserGroupResource;
import com.fdc.billingws.resources.UserResource;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.impl.ItemServiceImpl;
import com.fdc.billingws.services.impl.OrganizationServiceImpl;
import com.fdc.billingws.services.impl.PartyServiceImpl;
import com.fdc.billingws.services.impl.SalesInvoiceServiceImpl;
import com.fdc.billingws.services.impl.SettingServiceImpl;
import com.fdc.billingws.services.impl.UomServiceImpl;
import com.fdc.billingws.services.impl.UserGroupServiceImpl;
import com.fdc.billingws.services.impl.UserServiceImpl;

import io.dropwizard.Application;
import io.dropwizard.jdbi.DBIFactory;
import io.dropwizard.setup.Environment;

public class BillingWSApplication extends Application<BillingWSConfiguration> implements IBillingWS {

	public DBI jdbi = null;
	
	public static void main(String[] args) throws Exception {
		new BillingWSApplication().run(args);
	}

	public <T> T getDao(Class<T> daoClass) {
		return jdbi.onDemand(daoClass);
	}

	@Override
	public void run(BillingWSConfiguration configuration,Environment environment) throws Exception {
		final DBIFactory factory = new DBIFactory();
	    jdbi = factory.build(environment, configuration.getDatabase(), "MSSql");
	    
	    environment.jersey().register(new OrganizationResource(new OrganizationServiceImpl(this)));
	    environment.jersey().register(new SettingResource(new SettingServiceImpl(this)));
	    environment.jersey().register(new UserGroupResource(new UserGroupServiceImpl(this)));
	    environment.jersey().register(new UserResource(new UserServiceImpl(this)));
	    environment.jersey().register(new UomResource(new UomServiceImpl(this)));
	    environment.jersey().register(new ItemResource(new ItemServiceImpl(this)));
	    environment.jersey().register(new PartyResource(new PartyServiceImpl(this)));
	    environment.jersey().register(new SalesInvoiceResource(new SalesInvoiceServiceImpl(this)));
	}

}
