package com.fdc.billingws.general;

public enum Status {
	ERROR(500),
	NOT_FOUND(404),
	SUCCESS(200),
	VALID_DATA(100),
	INVALID_DATA(101),
	INVALID_LOGIN(600),
	ALIAS_SHOULD_NOT_BE_BLANK(601),
	NAME_SHOULD_NOT_BE_BLANK(602),
	ALIAS_ALREADY_EXISTS(701),
	NAME_ALREADY_EXISTS(702),
	ALIAS_DOES_NOT_EXISTS(703),
	NAME_DOES_NOT_EXISTS(704),
	REFNO_SHOULD_NOT_BE_BLANK(705),
	REFNO_ALREADY_EXISTS(706);
	private int status;
	Status(int status){
		this.status=status;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
