package com.fdc.billingws.services.impl;

import java.util.List;

import com.fdc.billingws.db.UserDao;
import com.fdc.billingws.db.UserGroupDao;
import com.fdc.billingws.dto.User;
import com.fdc.billingws.dto.UserGroup;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.IUserService;

public class UserServiceImpl implements IUserService {

	IBillingWS billingWS = null;
	
	public UserServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public User addUser(User user) {
		UserDao dao = billingWS.getDao(UserDao.class);
		Integer id = dao.addUser(user);
		user.setId(id);
		return user;
	}

	public User updateUser(User user) {
		UserDao dao = billingWS.getDao(UserDao.class);
		dao.updateUser(user);
		return user;
	}

	public void deleteUser(Integer id) {
		UserDao dao = billingWS.getDao(UserDao.class);
		dao.deleteUser(id);
	}

	public List<User> getUser(String query) {
		UserDao dao = billingWS.getDao(UserDao.class);
		List<User> listUser = dao.getUser(query);
		return listUser;
	}

	public UserGroup getUserGroup(Integer id) {
		UserGroupDao dao = billingWS.getDao(UserGroupDao.class);
		String query = "WHERE id = " + id;
		if (dao.getUserGroup(query).size() > 0){
			return dao.getUserGroup(query).get(0);	
		}	
		return null;
	}

}
