package com.fdc.billingws.db;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;
import org.skife.jdbi.v2.util.IntegerMapper;

import com.fdc.billingws.dto.Party;

@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)
public interface PartyDao {
    
	@SqlUpdate("INSERT INTO tblParty (type,alias,name,streetAddress,city,state,country,phoneNo,contactPerson,mobileNo,contactEmail,remarks) "
                + "VALUES (:type,:alias,:name,:streetAddress,:city,:state,:country,:phoneNo,:contactPerson,:mobileNo,:contactEmail,:remarks)")
	@GetGeneratedKeys
	public Integer addParty(@BindBean Party party);
	
	@SqlUpdate("UPDATE tblParty SET type=:type,alias=:alias,name=:name,streetAddress=:streetAddress,city=:city,state=:state,"
			+ "country=:country,phoneNo=:phoneNo,contactPerson=:contactPerson,mobileNo=:mobileNo,contactEmail=:contactEmail,"
			+ "remarks=:remarks WHERE id = :id")
	public void updateParty(@BindBean Party party);
	
    @SqlUpdate("DELETE FROM tblParty WHERE id = :id")
	public void deleteParty(@Bind("id") Integer id);
	
	@SqlQuery
	public List<Party> getParty(@Define("query") String query);
	
	@SqlQuery
	@Mapper(IntegerMapper.class)
	public Integer getCount(@Define("query") String query);
}
