/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fdc.billingws.db;

import com.fdc.billingws.dto.Item;

import java.util.List;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;
import org.skife.jdbi.v2.util.IntegerMapper;

@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)
public interface ItemDao {

	@SqlUpdate("INSERT INTO tblItem (alias,name,uId,sellingRate,buyingRate,remarks) "
            + "VALUES (:alias,:name,:uId,:sellingRate,:buyingRate,:remarks)")
	@GetGeneratedKeys
	public Integer addItem(@BindBean Item item);
	
	@SqlUpdate("UPDATE tblItem SET alias=:alias,name=:name,uId=:uId,sellingRate=:sellingRate,buyingRate=:buyingRate,remarks=:remarks"
			+  " WHERE id = :id")
	public void updateItem(@BindBean Item item);
	
	@SqlUpdate("DELETE FROM tblItem WHERE id = :id")
	public void deleteItem(@Bind("id") Integer id);
	
	@SqlQuery
	@Mapper(ItemMapper.class)
	public List<Item> getItem(@Define("query") String query);   

	@SqlQuery
	@Mapper(IntegerMapper.class)
	public Integer getCount(@Define("query") String query);
}
