package com.fdc.billingws.configuration;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.Configuration;
import io.dropwizard.db.DataSourceFactory;

public class BillingWSConfiguration extends Configuration {

	public DataSourceFactory getDatabase() {
		return database;
	}
	
	@Valid
    @NotNull
    @JsonProperty
    private final DataSourceFactory database = new DataSourceFactory();
}
