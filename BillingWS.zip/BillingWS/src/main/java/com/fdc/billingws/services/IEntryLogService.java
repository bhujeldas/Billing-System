package com.fdc.billingws.services;

import java.util.List;

import com.fdc.billingws.dto.EntryLog;

public interface IEntryLogService {

	public EntryLog addEntryLog(EntryLog entryLog);
	public EntryLog updateEntryLog(EntryLog entryLog);
	public void deleteEntryLog(Integer id);
	public List<EntryLog> getEntryLog(String query);
}
