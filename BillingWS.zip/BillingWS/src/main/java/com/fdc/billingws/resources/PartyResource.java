package com.fdc.billingws.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Party;
import com.fdc.billingws.dto.Response;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.IPartyService;
import com.google.common.base.Optional;

@Path("/billingws/Party")
@Produces(MediaType.APPLICATION_JSON)
public class PartyResource {

	final static Logger logger = Logger.getLogger(PartyResource.class);
	
	IPartyService partyService = null;

	public PartyResource(IPartyService partyService) {
		this.partyService = partyService;
	}
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addParty(Party party){
        try {		
        	String query;
    		if (party.getAlias() == null || party.getAlias().length()==0 ){
    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != party.getAlias() && party.getAlias().length() > 0){
    			query="SELECT * FROM tblParty WHERE alias = '" + party.getAlias() + "'";
    			if (partyService.getParty(query).size() > 0){
    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
    			}
    		}
    		if (party.getName() == null || party.getName().length()==0 ){
    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != party.getName() && party.getName().length() > 0){
    			query="SELECT * FROM tblParty WHERE name = '" + party.getName() + "'";
    			if (partyService.getParty(query).size() > 0){
    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
    			}
    		}
    		partyService.addParty(party);
        	return Response.ok(Status.SUCCESS.getStatus(), party, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> updateParty(@PathParam("id") Integer id,Party party){
        try {			
	        	String query;
	    		if (party.getAlias() == null || party.getAlias().length()==0 ){
	    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != party.getAlias() && party.getAlias().length() > 0){
	    			query="SELECT * FROM tblParty WHERE alias = '" + party.getAlias() + "' AND id <> " + id;
	    			if (partyService.getParty(query).size() > 0){
	    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
	    			}
	    		}
	    		if (party.getName() == null || party.getName().length()==0 ){
	    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != party.getName() && party.getName().length() > 0){
	    			query="SELECT * FROM tblParty WHERE name = '" + party.getName() + "' AND id <> " + id;
	    			if (partyService.getParty(query).size() > 0){
	    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
	    			}
	    		}			
	    		party.setId(id);
	    		partyService.updateParty(party);
                return Response.ok(Status.SUCCESS.getStatus(), party, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
                logger.info(e.getMessage());
                return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    @Path("/{id}")
    public Response<?> deleteParty(@PathParam("id") Integer id){
        try {			
        	partyService.deleteParty(id);
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getParty(@QueryParam("id") Optional<Integer> id,
    							@QueryParam("type") Optional<Integer> type,	                
    							@QueryParam("aliasLike") Optional<String> aliasLike,
    							@QueryParam("alias") Optional<String> alias,
				                @QueryParam("name") Optional<String> name,
				                @QueryParam("nameLike") Optional<String> nameLike,
				                @QueryParam("orderBy") Optional<String> orderBy,
				                @QueryParam("pageNo") Optional<Integer> pageNo,
				                @QueryParam("rowCount") Optional<Integer> rowCount){
    	try{
    		Double endNo = 0d;
			Integer currentNo = 0;
			
			List<Party> listParty = new ArrayList<Party>();
				
			String query="";
			String inQuery = "SELECT id,type,CASE WHEN p.type = 1 THEN 'Vedor' WHEN p.type = 2 THEN 'Both' ELSE 'Customer' END AS typeName,"
					       + "alias,name,streetAddress,city,state,country,phoneNo,contactPerson,mobileNo,contactEmail,"
					       + "remarks FROM tblParty AS p WHERE p.id IS NOT NULL";			
			if(id.isPresent())
				inQuery = inQuery + " AND p.id = " + id.get();
			if(type.isPresent()){
				if (type.get() == 3){
					inQuery = inQuery + " AND p.type IN (0,2)";	
				}else if (type.get() == 4){
					inQuery = inQuery + " AND p.type IN (1,2)";
				}else{
					inQuery = inQuery + " AND p.type = " + type.get();
				}				
			}
			if(aliasLike.isPresent())
				inQuery = inQuery + " AND p.alias LIKE '" + aliasLike.get() + "%'";
			if(alias.isPresent())
				inQuery = inQuery + " AND p.alias = '" + alias.get() + "'";
			if(nameLike.isPresent())
				inQuery = inQuery + " AND p.name LIKE '" + nameLike.get() + "%'";
			if(name.isPresent())
				inQuery = inQuery + " AND p.name = '" + name.get() + "'";
			
			if (orderBy.isPresent() && pageNo.isPresent() && rowCount.isPresent()){
				query = "SELECT * FROM ( SELECT * , ROW_NUMBER() OVER (ORDER BY " + orderBy.get() + ") AS row FROM (";
				query = query + inQuery + ") AS IT ) AS OT "
						+ "WHERE row >= " + (1 + ((pageNo.get()-1) * rowCount.get())) + " AND  row <= " + (pageNo.get() * rowCount.get());
				
				endNo = Double.valueOf(partyService.getCount(inQuery));
				endNo = Math.ceil(endNo / rowCount.get());
				currentNo = pageNo.get();				
			}else{
				query = inQuery;
				if (orderBy.isPresent()) {
					query = query + " ORDER BY " + orderBy.get();
				}
			}
			listParty.addAll(partyService.getParty(query));
			
			return Response.ok(Status.SUCCESS.getStatus(), listParty, Messages.SUCCESS.getMessage(),currentNo,endNo.intValue());
		} catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
		}
    }	
}
