package com.fdc.billingws.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import com.fdc.billingws.dto.Item;
import com.fdc.billingws.dto.Uom;

public class ItemMapper implements ResultSetMapper<Item>{

	public Item map(int index, ResultSet ruleset, StatementContext ctx) throws SQLException {
		Item item = new Item();
		Uom uom = null;
		
		item.setId(Integer.parseInt(ruleset.getString("id")));
		item.setAlias(ruleset.getString("alias"));
		item.setName(ruleset.getString("name"));
		if (null != ruleset.getString("uId")){
			item.setuId(Integer.parseInt(ruleset.getString("uId")));
			
			uom = new Uom();
			uom.setId(Integer.parseInt(ruleset.getString("uId")));
			uom.setAlias(ruleset.getString("uAlias"));
			uom.setName(ruleset.getString("uName"));
			uom.setRemarks(ruleset.getString("uRemarks"));
		}
		item.setUom(uom);
		item.setSellingRate(Float.parseFloat(ruleset.getString("sellingRate")));
		item.setBuyingRate(Float.parseFloat(ruleset.getString("buyingRate")));
		item.setRemarks(ruleset.getString("remarks"));
		return item;		
	}

}
