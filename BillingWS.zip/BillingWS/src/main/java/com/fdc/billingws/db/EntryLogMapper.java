package com.fdc.billingws.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import com.fdc.billingws.dto.EntryLog;
import com.fdc.billingws.dto.User;

public class EntryLogMapper implements ResultSetMapper<EntryLog> {

	public EntryLog map(int index, ResultSet ruleset, StatementContext ctx) {
		
		EntryLog entryLog = null;
		try {
			entryLog = new EntryLog();
			User user = null;
			
			entryLog.setId(Integer.parseInt(ruleset.getString("id")));
			entryLog.setInvNo(ruleset.getString("invNo"));
			entryLog.setInvDate(ruleset.getString("invDate"));
			entryLog.setAction(ruleset.getString("action"));
			entryLog.setActionDate(ruleset.getString("actionDate"));
			if (null != ruleset.getString("userId")){
				entryLog.setUserId(Integer.parseInt(ruleset.getString("userId")));
				
				user = new User();
				user.setId(Integer.parseInt(ruleset.getString("userId")));
				user.setUserName(ruleset.getString("userName"));
				user.setLoginName(ruleset.getString("loginName"));
				user.setPassword(ruleset.getString("password"));
				user.setUgId(Integer.parseInt(ruleset.getString("ugId")));
				user.setRemarks(ruleset.getString("uRemarks"));
			}
			entryLog.setUser(user);
		} catch (Exception e) {
			System.out.println("Error on entrylog mapping " + e.getMessage());
		}
		return entryLog;		
	}

}
