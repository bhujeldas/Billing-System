package com.fdc.billingws.services;

import java.util.List;

import com.fdc.billingws.dto.User;
import com.fdc.billingws.dto.UserGroup;

public interface IUserService {

	public User addUser(User user);
    public User updateUser(User user);
    public void deleteUser(Integer id);
    public List<User> getUser(String query);
    public UserGroup getUserGroup(Integer id);
}
