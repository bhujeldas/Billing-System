package com.fdc.billingws.db;

import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;

import com.fdc.billingws.dto.Organization;

@RegisterMapperFactory(BeanMapperFactory.class)
public interface OrganizationDao {

	@SqlUpdate("INSERT INTO tblOrganization (name,address,phoneNo,email,site,panNo,contactPerson,mobileNo,contactEmail,slogan,logo) "
			  + "VALUES (:name,:address,:phoneNo,:email,:site,:panNo,:contactPerson,:mobileNo,:contactEmail,:slogan,:logo)")
	public void addOrganization(@BindBean Organization organization);
	
	@SqlUpdate("DELETE FROM tblOrganization")
	public void deleteOrganization();
	
	@SqlQuery("SELECT * FROM tblOrganization")
	public Organization getOrganization();
}
