package com.fdc.billingws.services;

import com.fdc.billingws.dto.Organization;

public interface IOrganizationService {

	public Organization addOrganization(Organization organization);
	public void deleteOrganization();
	public Organization getOrganization();
	
}
