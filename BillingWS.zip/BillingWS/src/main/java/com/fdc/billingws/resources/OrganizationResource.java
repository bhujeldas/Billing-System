package com.fdc.billingws.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Organization;
import com.fdc.billingws.dto.Response;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.IOrganizationService;

@Path("/billingws/Organization")
@Produces(MediaType.APPLICATION_JSON)
public class OrganizationResource {
	final static Logger logger = Logger.getLogger(Organization.class);
	
	IOrganizationService organizationService =null;
	
	public OrganizationResource(IOrganizationService organizationService) {
        this.organizationService=organizationService;
	}
	
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addOrganization(Organization organization){
        try {			
        	organizationService.addOrganization(organization);
        	return Response.ok(Status.SUCCESS.getStatus(), organization, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    public Response<?> deleteOrganization(){
        try {			
			organizationService.deleteOrganization();
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getOrganization(){
        try{
			Organization organization = organizationService.getOrganization();
			return Response.ok(Status.SUCCESS.getStatus(), organization, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }
    }

}
