package com.fdc.billingws.services.impl;

import java.util.List;

import com.fdc.billingws.db.ItemDao;
import com.fdc.billingws.db.PartyDao;
import com.fdc.billingws.dto.Party;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.IPartyService;

public class PartyServiceImpl implements IPartyService {
	
	IBillingWS billingWS = null;
	
	public PartyServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public Party addParty(Party party) {
		PartyDao dao = billingWS.getDao(PartyDao.class);
		Integer id = dao.addParty(party);
		party.setId(id);
		return party;
	}

	public Party updateParty(Party party) {
		PartyDao dao = billingWS.getDao(PartyDao.class);
		dao.updateParty(party);
		return party;
	}

	public void deleteParty(Integer id) {
		PartyDao dao = billingWS.getDao(PartyDao.class);
		dao.deleteParty(id);
	}

	public List<Party> getParty(String query) {
		PartyDao dao = billingWS.getDao(PartyDao.class);
		List<Party> listParty = dao.getParty(query);
		return listParty;
	}

	public Integer getCount(String query) {
		PartyDao dao = billingWS.getDao(PartyDao.class);
        Integer count = dao.getCount(query);
        return count;
	}

}
