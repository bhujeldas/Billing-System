package com.fdc.billingws.services.impl;

import java.util.List;

import com.fdc.billingws.db.ItemDao;
import com.fdc.billingws.db.UomDao;
import com.fdc.billingws.dto.Item;
import com.fdc.billingws.dto.Uom;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.IItemService;

public class ItemServiceImpl implements IItemService {

	IBillingWS billingWS = null;
	
	public ItemServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public Item addItem(Item item) {
		ItemDao dao = billingWS.getDao(ItemDao.class);
		Integer id = dao.addItem(item);
		item.setId(id);
		return item;
	}

	public Item updateItem(Item item) {
		ItemDao dao = billingWS.getDao(ItemDao.class);
		dao.updateItem(item);
		return item;
	}

	public void deleteItem(Integer id) {
		ItemDao dao = billingWS.getDao(ItemDao.class);
		dao.deleteItem(id);
	}

	public List<Item> getItem(String query) {
		ItemDao dao = billingWS.getDao(ItemDao.class);
		List<Item> listItem = dao.getItem(query);
		return listItem;
	}

	public Uom getUom(Integer id) {
		UomDao dao = billingWS.getDao(UomDao.class);
		String query = "SELECT * FROM tblUom WHERE id = " + id;
		if (dao.getUOM(query).size() > 0){
			return dao.getUOM(query).get(0);	
		}	
		return null;
	}

	public Integer getCount(String query) {
		ItemDao dao = billingWS.getDao(ItemDao.class);
        Integer count = dao.getCount(query);
        return count;
	}

}
