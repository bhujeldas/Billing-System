package com.fdc.billingws.services.impl;

import java.util.List;

import com.fdc.billingws.db.EntryLogDao;
import com.fdc.billingws.dto.EntryLog;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.IEntryLogService;

public class EntryLogServiceImpl implements IEntryLogService {

	IBillingWS billingWS = null;
			
	public EntryLogServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public EntryLog addEntryLog(EntryLog entryLog) {
		EntryLogDao dao = billingWS.getDao(EntryLogDao.class);
		Integer id = dao.addEntryLog(entryLog);
		entryLog.setId(id);
		return entryLog;
	}

	public EntryLog updateEntryLog(EntryLog entryLog) {
		EntryLogDao dao = billingWS.getDao(EntryLogDao.class);
		dao.updateEntryLog(entryLog);
		return entryLog;
	}

	public void deleteEntryLog(Integer id) {
		EntryLogDao dao = billingWS.getDao(EntryLogDao.class);
		dao.deleteEntryLog(id);
	}

	public List<EntryLog> getEntryLog(String query) {
		EntryLogDao dao = billingWS.getDao(EntryLogDao.class);
		List<EntryLog> listEntryLog = dao.getEntryLog(query);
		return listEntryLog;
	}

}
