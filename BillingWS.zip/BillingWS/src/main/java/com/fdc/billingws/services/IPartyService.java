package com.fdc.billingws.services;

import java.util.List;

import com.fdc.billingws.dto.Party;

public interface IPartyService {

	public Party addParty(Party party);
    public Party updateParty(Party party);
    public void deleteParty(Integer id);
    public List<Party> getParty(String query);
    public Integer getCount(String query);
    
}
