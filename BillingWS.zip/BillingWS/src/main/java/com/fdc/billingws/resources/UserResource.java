package com.fdc.billingws.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Response;
import com.fdc.billingws.dto.User;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.IUserService;
import com.google.common.base.Optional;

@Path("/billingws/User")
@Produces(MediaType.APPLICATION_JSON)
public class UserResource {

	final static Logger logger = Logger.getLogger(User.class);
	
	IUserService userService = null;

	public UserResource(IUserService userService) {
		this.userService = userService;
	}
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addUser(User user){
        try {		
        	String query;
    		if (user.getUserName() == null || user.getUserName().length()==0 ){
    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != user.getUserName() && user.getUserName().length() > 0){
    			query="WHERE u.userName = '" + user.getUserName() + "'";
    			if (userService.getUser(query).size() > 0){
    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
    			}
    		}
    		if (user.getLoginName() == null || user.getLoginName().length()==0 ){
    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != user.getLoginName() && user.getLoginName().length() > 0){
    			query="WHERE loginName = '" + user.getLoginName() + "'";
    			if (userService.getUser(query).size() > 0){
    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
    			}
    		}
        	userService.addUser(user);
			if (null != user.getUgId())
        	{
        		if(null != userService.getUserGroup(user.getUgId())) {
        			user.setUserGroup(userService.getUserGroup(user.getUgId()));	
        		}        		
        	}
        	return Response.ok(Status.SUCCESS.getStatus(), user, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> updateUser(@PathParam("id") Integer id,User user){
        try {			
	        	String query;
	    		if (user.getUserName() == null || user.getUserName().length()==0 ){
	    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != user.getUserName() && user.getUserName().length() > 0){
	    			query="WHERE userName = '" + user.getUserName() + "' AND u.id <> " + id;
	    			if (userService.getUser(query).size() > 0){
	    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
	    			}
	    		}
	    		if (user.getLoginName() == null || user.getLoginName().length()==0 ){
	    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != user.getLoginName() && user.getLoginName().length() > 0){
	    			query="WHERE loginName = '" + user.getLoginName() + "' AND u.id <> " + id;
	    			if (userService.getUser(query).size() > 0){
	    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
	    			}
	    		}			
                user.setId(id);
                userService.updateUser(user);
                if (null != user.getUgId())
            	{
            		if(null != userService.getUserGroup(user.getUgId())) {
            			user.setUserGroup(userService.getUserGroup(user.getUgId()));	
            		}        		
            	}
                return Response.ok(Status.SUCCESS.getStatus(), user, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
                logger.info(e.getMessage());
                return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    @Path("/{id}")
    public Response<?> deleteUser(@PathParam("id") Integer id){
        try {			
			userService.deleteUser(id);
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getUser(@QueryParam("id") Optional<Integer> id,
				               @QueryParam("userName") Optional<String> userName,
				               @QueryParam("loginName") Optional<String> loginName){
    	try{
			List<User> listUser = new ArrayList<User>();
				
			String query = " WHERE u.id IS NOT NULL";
			if(id.isPresent())
			     query = query + " AND u.id = " + id.get();
			if(userName.isPresent())
			      query = query + " AND u.userNaem = '" + userName.get() + "'";
			if(loginName.isPresent())
			      query = query + " AND name = '" + loginName.get() + "'";
			
			listUser.addAll(userService.getUser(query));
			
			return Response.ok(Status.SUCCESS.getStatus(), listUser, Messages.SUCCESS.getMessage());
		} catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
		}
    }
	
}
