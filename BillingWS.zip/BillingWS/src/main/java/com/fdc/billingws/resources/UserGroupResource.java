package com.fdc.billingws.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Response;
import com.fdc.billingws.dto.UserGroup;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.IUserGroupService;
import com.google.common.base.Optional;

@Path("/billingws/UserGroup")
@Produces(MediaType.APPLICATION_JSON)
public class UserGroupResource {

	final static Logger logger = Logger.getLogger(UserGroupResource.class);
	
	IUserGroupService userGroupService = null;

	public UserGroupResource(IUserGroupService userGroupService) {
		this.userGroupService = userGroupService;
	}
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addUserGroup(UserGroup userGroup){
        try {		
        	String query;
    		if (userGroup.getAlias() == null || userGroup.getAlias().length()==0 ){
    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != userGroup.getAlias() && userGroup.getAlias().length() > 0){
    			query="WHERE alias = '" + userGroup.getAlias() + "'";
    			if (userGroupService.getUserGroup(query).size() > 0){
    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
    			}
    		}
    		if (userGroup.getName() == null || userGroup.getName().length()==0 ){
    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != userGroup.getName() && userGroup.getName().length() > 0){
    			query="WHERE name = '" + userGroup.getName() + "'";
    			if (userGroupService.getUserGroup(query).size() > 0){
    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
    			}
    		}
        	userGroupService.addUserGroup(userGroup);
        	return Response.ok(Status.SUCCESS.getStatus(), userGroup, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> updateUserGroup(@PathParam("id") Integer id,UserGroup userGroup){
        try {			
	        	String query;
	    		if (userGroup.getAlias() == null || userGroup.getAlias().length()==0 ){
	    			return Response.error(Messages.ALIAS_SHOULD_NOT_BE_BLANK.getMessage(), Status.ALIAS_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != userGroup.getAlias() && userGroup.getAlias().length() > 0){
	    			query="WHERE alias = '" + userGroup.getAlias() + "' AND id <> " + id;
	    			if (userGroupService.getUserGroup(query).size() > 0){
	    				return Response.error(Messages.ALIAS_ALREADY_EXISTS.getMessage(), Status.ALIAS_ALREADY_EXISTS.getStatus());
	    			}
	    		}
	    		if (userGroup.getName() == null || userGroup.getName().length()==0 ){
	    			return Response.error(Messages.NAME_SHOULD_NOT_BE_BLANK.getMessage(), Status.NAME_SHOULD_NOT_BE_BLANK.getStatus());
	    		}else if (null != userGroup.getName() && userGroup.getName().length() > 0){
	    			query="WHERE name = '" + userGroup.getName() + "' AND id <> " + id;
	    			if (userGroupService.getUserGroup(query).size() > 0){
	    				return Response.error(Messages.NAME_ALREADY_EXISTS.getMessage(), Status.NAME_ALREADY_EXISTS.getStatus());
	    			}
	    		}			
                userGroup.setId(id);
                userGroupService.updateUserGroup(userGroup);
                return Response.ok(Status.SUCCESS.getStatus(), userGroup, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
                logger.info(e.getMessage());
                return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    @Path("/{id}")
    public Response<?> deleteUserGroup(@PathParam("id") Integer id){
        try {			
			userGroupService.deleteUserGroup(id);
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getUserGroup(@QueryParam("id") Optional<Integer> id,
				            @QueryParam("alias") Optional<String> alias,
				            @QueryParam("name") Optional<String> name){
    	try{
			List<UserGroup> listUserGroup = new ArrayList<UserGroup>();
				
			String query = " WHERE id IS NOT NULL";
			if(id.isPresent())
			     query = query + " AND id = " + id.get();
			if(alias.isPresent())
			      query = query + " AND alias = '" + alias.get() + "'";
			if(name.isPresent())
			      query = query + " AND name = '" + name.get() + "'";
			
			listUserGroup.addAll(userGroupService.getUserGroup(query));
			
			return Response.ok(Status.SUCCESS.getStatus(), listUserGroup, Messages.SUCCESS.getMessage());
		} catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
		}
    }
}