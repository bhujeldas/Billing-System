package com.fdc.billingws.services;

public interface IBillingWS {
	<T> T getDao(Class<T> daoClass);
}
