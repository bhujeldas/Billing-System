package com.fdc.billingws.db;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;

import com.fdc.billingws.dto.EntryLog;

@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)
public interface EntryLogDao {

	@SqlUpdate("INSERT INTO tblEntryLog (userId,module,invNo,invDate,amount,action,actionDate) "
            + "VALUES (:userId,:module,:invNo,:invDate,:amount,:action,:actionDate)")
	@GetGeneratedKeys
	public Integer addEntryLog(@BindBean EntryLog entryLog);
	
	@SqlUpdate("UPDATE tblEntryLog SET userId=:userId,module=:module,invNo=:invNo,invDate=:invDate,amount=:amount,"
			+ "amount=:amount,actionDate=:actionDate"
			+  " WHERE id = :id")
	public void updateEntryLog(@BindBean EntryLog entryLog);
	
	@SqlUpdate("DELETE FROM tblEntryLog WHERE id = :id")
	public void deleteEntryLog(@Bind("id") Integer id);
	
	@SqlQuery
	@Mapper(EntryLogMapper.class)
	public List<EntryLog> getEntryLog(@Define("query") String query);   
}
