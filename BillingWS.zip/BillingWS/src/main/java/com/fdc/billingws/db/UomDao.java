/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fdc.billingws.db;

import com.fdc.billingws.dto.Uom;
import java.util.List;
import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;
import org.skife.jdbi.v2.util.IntegerMapper;

/**
 *
 * @author IOCD
 */
@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)

public interface UomDao {
    @SqlUpdate("INSERT INTO tblUom (alias,name,remarks) "
                + "VALUES (:alias,:name,:remarks)")
	@GetGeneratedKeys
	public Integer addUOM(@BindBean Uom uom);
	
	@SqlUpdate("UPDATE tblUom SET alias=:alias,name=:name,remarks=:remarks"
			+  " WHERE id = :id")
	public void updateUOM(@BindBean Uom uom);
	
    @SqlUpdate("DELETE FROM tblUom WHERE id = :id")
	public void deleteUOM(@Bind("id") Integer id);
	
	@SqlQuery
	public List<Uom> getUOM(@Define("query") String query);
	
	@SqlQuery
	@Mapper(IntegerMapper.class)
	public Integer getCount(@Define("query") String query);
   
}
