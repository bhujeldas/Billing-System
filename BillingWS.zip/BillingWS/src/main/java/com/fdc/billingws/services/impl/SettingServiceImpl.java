/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fdc.billingws.services.impl;

import com.fdc.billingws.db.SettingDao;
import com.fdc.billingws.dto.Setting;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.ISettingService;

public class SettingServiceImpl implements ISettingService {
    IBillingWS billingWS = null;
	
    public SettingServiceImpl(IBillingWS billingWS) {
        this.billingWS=billingWS;
    }

    public Setting addSetting(Setting setting) {
        SettingDao dao= billingWS.getDao(SettingDao.class);
        dao.addSetting(setting);
        return setting;
    }

    public void deleteSetting() {
        SettingDao dao=billingWS.getDao(SettingDao.class);
        dao.deleteSetting();
    }

    public Setting getSetting() {
        SettingDao dao=billingWS.getDao(SettingDao.class);
        return dao.getSetting();
    }
    
}
