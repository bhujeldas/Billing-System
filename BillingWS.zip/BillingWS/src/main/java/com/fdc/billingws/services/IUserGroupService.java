package com.fdc.billingws.services;

import java.util.List;

import com.fdc.billingws.dto.UserGroup;

public interface IUserGroupService {

    public UserGroup addUserGroup(UserGroup userGroup);
    public UserGroup updateUserGroup(UserGroup userGroup);
    public void deleteUserGroup(Integer id);
    public List<UserGroup> getUserGroup(String query);
}
