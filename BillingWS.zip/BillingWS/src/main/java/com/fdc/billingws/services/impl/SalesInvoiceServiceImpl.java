package com.fdc.billingws.services.impl;

import java.util.List;

import com.fdc.billingws.db.SalesInvoiceDao;
import com.fdc.billingws.dto.SalesInvoiceDetails;
import com.fdc.billingws.dto.SalesInvoiceMaster;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.ISalesInvoiceService;

public class SalesInvoiceServiceImpl implements ISalesInvoiceService{
	
	IBillingWS billingWS = null;
	
	public SalesInvoiceServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public SalesInvoiceMaster addSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		Integer siId = dao.addSalesInvoiceMaster(salesInvoiceMaster);
		salesInvoiceMaster.setSiId(siId);
		return salesInvoiceMaster;
	}

	public SalesInvoiceMaster updateSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		dao.updateSalesInvoiceMaster(salesInvoiceMaster);
		return salesInvoiceMaster;
	}

	public void deleteSalesInvoiceMaster(Integer siId) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		dao.deleteSalesInvoiceMaster(siId);
		
	}

	public List<SalesInvoiceMaster> getSalesInvoiceMaster(String query) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		List<SalesInvoiceMaster> listSalesInvoiceMaster = dao.getSalesInvoiceMaster(query);
		for(SalesInvoiceMaster si:listSalesInvoiceMaster){
			query = " WHERE sd.siId = " + si.getSiId() + " ORDER BY Sno";
			List<SalesInvoiceDetails> listSalesInvoiceDetails = getSalesInvoiceDetails(query);
			si.setSalesInvoiceDetails(listSalesInvoiceDetails);
		}
		return listSalesInvoiceMaster;
	}

	public List<SalesInvoiceDetails> addSalesInvoiceDetails(Integer siId,List<SalesInvoiceDetails> listSalesInvoiceDetails) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		for(SalesInvoiceDetails sd:listSalesInvoiceDetails){
			sd.setSiId(siId);
			dao.addSalesInvoiceDetails(sd);				
		}		
		return listSalesInvoiceDetails;
	}


	public List<SalesInvoiceDetails> updateSalesInvoiceDetails(Integer siId,List<SalesInvoiceDetails> listSalesInvoiceDetails) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		for(SalesInvoiceDetails sd:listSalesInvoiceDetails){
			dao.updateSalesInvoiceDetails(sd);				
		}		
		return listSalesInvoiceDetails;
	}
	
	public void deleteSalesInvoiceDetails(Integer siId) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		dao.deleteSalesInvoiceDetails(siId);		
	}

	public List<SalesInvoiceDetails> getSalesInvoiceDetails(String query) {
		SalesInvoiceDao dao = billingWS.getDao(SalesInvoiceDao.class);
		List<SalesInvoiceDetails> listSalesInvoiceDetails = dao.getSalesInvoiceDetails(query);
		return listSalesInvoiceDetails;
	}

	

}
