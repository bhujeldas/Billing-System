package com.fdc.billingws.db;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;

import com.fdc.billingws.dto.UserGroup;

@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)
public interface UserGroupDao {
	
    @SqlUpdate("INSERT INTO tblUserGroup (alias,name,remarks) "
                + "VALUES (:alias,:name,:remarks)")
	@GetGeneratedKeys
	public Integer addUserGroup(@BindBean UserGroup userGroup);
	
	@SqlUpdate("UPDATE tblUserGroup SET alias=:alias,name=:name,remarks=:remarks"
			+  " WHERE id = :id")
	public void updateUserGroup(@BindBean UserGroup userGroup);
	
    @SqlUpdate("DELETE FROM tblUserGroup WHERE id = :id")
	public void deleteUserGroup(@Bind("id") Integer id);
	
	@SqlQuery
	public List<UserGroup> getUserGroup(@Define("query") String query);
	   
}
