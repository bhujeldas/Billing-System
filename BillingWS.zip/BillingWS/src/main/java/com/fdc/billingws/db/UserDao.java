package com.fdc.billingws.db;

import java.util.List;

import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.GetGeneratedKeys;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.Define;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.stringtemplate.UseStringTemplate3StatementLocator;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;

import com.fdc.billingws.dto.User;

@UseStringTemplate3StatementLocator
@RegisterMapperFactory(BeanMapperFactory.class)
public interface UserDao {

	@SqlUpdate("INSERT INTO tblUser (userName,loginName,password,ugId,remarks) "
            + "VALUES (:userName,:loginName,:password,:ugId,:remarks)")
	@GetGeneratedKeys
	public Integer addUser(@BindBean User user);
	
	@SqlUpdate("UPDATE tblUser SET userName=:userName,loginName=:loginName,password=:password,ugId=:ugId,remarks=:remarks"
			+  " WHERE id = :id")
	public void updateUser(@BindBean User user);
	
	@SqlUpdate("DELETE FROM tblUser WHERE id = :id")
	public void deleteUser(@Bind("id") Integer id);
	
	@SqlQuery
	@Mapper(UserMapper.class)
	public List<User> getUser(@Define("query") String query);
}
