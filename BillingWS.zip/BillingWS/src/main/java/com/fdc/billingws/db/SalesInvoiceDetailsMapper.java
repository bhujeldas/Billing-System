package com.fdc.billingws.db;

import java.sql.ResultSet;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import com.fdc.billingws.dto.Item;
import com.fdc.billingws.dto.SalesInvoiceDetails;
import com.fdc.billingws.dto.Uom;

public class SalesInvoiceDetailsMapper implements ResultSetMapper<SalesInvoiceDetails>{

	public SalesInvoiceDetails map(int index, ResultSet ruleset, StatementContext ctx) {
		SalesInvoiceDetails salesInvoiceDetails = new SalesInvoiceDetails();
		try {
			Item item = null;
			Uom uom = null;
			salesInvoiceDetails.setSiId(Integer.parseInt(ruleset.getString("siId")));
			salesInvoiceDetails.setSno(Integer.parseInt(ruleset.getString("sno")));
			if (null != ruleset.getString("itemId")){
				salesInvoiceDetails.setItemId(Integer.parseInt(ruleset.getString("itemId")));
				item = new Item();
				item.setId(Integer.parseInt(ruleset.getString("itemId")));
				item.setAlias(ruleset.getString("iAlias"));
				item.setName(ruleset.getString("iName"));
				if (null != ruleset.getString("iUId")){
					item.setuId(Integer.parseInt(ruleset.getString("iUId")));
				}
				item.setSellingRate(Float.parseFloat(ruleset.getString("isellingRate")));
				item.setBuyingRate(Float.parseFloat(ruleset.getString("ibuyingRate")));
				item.setRemarks(ruleset.getString("iRemarks"));
			}
			salesInvoiceDetails.setItem(item);
			salesInvoiceDetails.setQty(Float.parseFloat(ruleset.getString("qty")));
			if (null != ruleset.getString("uId")){
				salesInvoiceDetails.setuId(Integer.parseInt(ruleset.getString("uId")));
				uom = new Uom();
				uom.setId(Integer.parseInt(ruleset.getString("uId")));
				uom.setAlias(ruleset.getString("uAlias"));
				uom.setName(ruleset.getString("uName"));
				uom.setRemarks(ruleset.getString("uRemarks"));
			}
			salesInvoiceDetails.setUom(uom);
			salesInvoiceDetails.setRate(Float.parseFloat(ruleset.getString("rate")));
			salesInvoiceDetails.setAmount(Float.parseFloat(ruleset.getString("amount")));
			salesInvoiceDetails.setNarration(ruleset.getString("narration"));
		} catch (Exception e) {
			System.out.println("error on sales invoice detail mapper " + e.getMessage());
		}
		return salesInvoiceDetails;
	}

}
