package com.fdc.billingws.services;

import java.util.List;

import com.fdc.billingws.dto.Item;
import com.fdc.billingws.dto.Uom;

public interface IItemService {
	
	public Item addItem(Item item);
	public Item updateItem(Item item);
	public void deleteItem(Integer id);
	public List<Item> getItem(String query);
	public Uom getUom(Integer id);
	public Integer getCount(String query);

}
