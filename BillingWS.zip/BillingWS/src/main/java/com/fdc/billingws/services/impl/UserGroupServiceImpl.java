package com.fdc.billingws.services.impl;

import java.util.List;

import com.fdc.billingws.db.UserGroupDao;
import com.fdc.billingws.dto.UserGroup;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.IUserGroupService;

public class UserGroupServiceImpl implements IUserGroupService {

	IBillingWS billingWS = null;
	
	public UserGroupServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public UserGroup addUserGroup(UserGroup userGroup) {
		UserGroupDao dao = billingWS.getDao(UserGroupDao.class);
		Integer id = dao.addUserGroup(userGroup);
		userGroup.setId(id);
		return userGroup;
	}

	public UserGroup updateUserGroup(UserGroup userGroup) {
		UserGroupDao dao = billingWS.getDao(UserGroupDao.class);
		dao.updateUserGroup(userGroup);		
		return userGroup;
	}

	public void deleteUserGroup(Integer id) {
		UserGroupDao dao= billingWS.getDao(UserGroupDao.class);
		dao.deleteUserGroup(id);
	}

	public List<UserGroup> getUserGroup(String query) {
		UserGroupDao dao = billingWS.getDao(UserGroupDao.class);
		List<UserGroup> listUserGroup = dao.getUserGroup(query);
		return listUserGroup;
	}

}
