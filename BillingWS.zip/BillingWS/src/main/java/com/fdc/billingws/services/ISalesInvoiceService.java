package com.fdc.billingws.services;

import java.util.List;

import com.fdc.billingws.dto.SalesInvoiceDetails;
import com.fdc.billingws.dto.SalesInvoiceMaster;

public interface ISalesInvoiceService {
	
	public SalesInvoiceMaster addSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster);
	public SalesInvoiceMaster updateSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster);
	public void deleteSalesInvoiceMaster(Integer siId);
	public List<SalesInvoiceMaster> getSalesInvoiceMaster(String query);

	public List<SalesInvoiceDetails> addSalesInvoiceDetails(Integer siId,List<SalesInvoiceDetails> listSalesInvoiceDetails);
	public List<SalesInvoiceDetails> updateSalesInvoiceDetails(Integer siId,List<SalesInvoiceDetails> listSalesInvoiceDetails);
	public void deleteSalesInvoiceDetails(Integer siId);
	public List<SalesInvoiceDetails> getSalesInvoiceDetails(String query);
	
}
