/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fdc.billingws.services;

import com.fdc.billingws.dto.Uom;
import java.util.List;

public interface IUomService {
    public Uom addUom(Uom uom);
    public Uom updateUom(Uom uom);
    public void deleteUom(Integer id);
    public List<Uom> getUom(String query);
    public Integer getCount(String query);
}
