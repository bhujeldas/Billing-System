package com.fdc.billingws.resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Response;
import com.fdc.billingws.dto.SalesInvoiceMaster;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.ISalesInvoiceService;
import com.google.common.base.Optional;

@Path("/billingws/SalesInvoiceMaster")
@Produces(MediaType.APPLICATION_JSON)
public class SalesInvoiceResource {

	final static Logger logger = Logger.getLogger(SalesInvoiceResource.class);
	
	ISalesInvoiceService salesInvoiceService = null;

	public SalesInvoiceResource(ISalesInvoiceService salesInvoiceService) {
		this.salesInvoiceService = salesInvoiceService;
	}
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster){
        try {			
        	String query;
    		if (salesInvoiceMaster.getSiNo() == null || salesInvoiceMaster.getSiNo().length()==0 ){
    			return Response.error(Messages.REFNO_SHOULD_NOT_BE_BLANK.getMessage(), Status.REFNO_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != salesInvoiceMaster.getSiNo() && salesInvoiceMaster.getSiNo().length() > 0){
    			query="WHERE si.siNo = '" + salesInvoiceMaster.getSiNo() + "'";
    			if (salesInvoiceService.getSalesInvoiceMaster(query).size() > 0){
    				return Response.error(Messages.REFNO_ALREADY_EXISTS.getMessage(), Status.REFNO_ALREADY_EXISTS.getStatus());
    			}
    		}
        	salesInvoiceService.addSalesInvoiceMaster(salesInvoiceMaster);
        	salesInvoiceService.addSalesInvoiceDetails(salesInvoiceMaster.getSiId(), salesInvoiceMaster.getSalesInvoiceDetails());
        	
        	query="WHERE si.siId = " + salesInvoiceMaster.getSiId();
        	salesInvoiceMaster = salesInvoiceService.getSalesInvoiceMaster(query).get(0);        	
        	return Response.ok(Status.SUCCESS.getStatus(), salesInvoiceMaster, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@PUT
	@Path("/{siId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> updateSalesInvoiceMaster(@PathParam("siId") Integer siId,SalesInvoiceMaster salesInvoiceMaster){
        try {			
        	String query;
    		if (salesInvoiceMaster.getSiNo() == null || salesInvoiceMaster.getSiNo().length()==0 ){
    			return Response.error(Messages.REFNO_SHOULD_NOT_BE_BLANK.getMessage(), Status.REFNO_SHOULD_NOT_BE_BLANK.getStatus());
    		}else if (null != salesInvoiceMaster.getSiNo() && salesInvoiceMaster.getSiNo().length() > 0){
    			query="WHERE si.siNo = '" + salesInvoiceMaster.getSiNo() + "' AND siId <> " + siId;
    			if (salesInvoiceService.getSalesInvoiceMaster(query).size() > 0){
    				return Response.error(Messages.REFNO_ALREADY_EXISTS.getMessage(), Status.REFNO_ALREADY_EXISTS.getStatus());
    			}
    		}
    		salesInvoiceMaster.setSiId(siId);
        	salesInvoiceService.updateSalesInvoiceMaster(salesInvoiceMaster);
        	salesInvoiceService.deleteSalesInvoiceDetails(siId);
        	salesInvoiceService.addSalesInvoiceDetails(siId, salesInvoiceMaster.getSalesInvoiceDetails());
        	
        	query="WHERE si.siId = " + salesInvoiceMaster.getSiId() ;
        	salesInvoiceMaster = salesInvoiceService.getSalesInvoiceMaster(query).get(0);
        	return Response.ok(Status.SUCCESS.getStatus(), salesInvoiceMaster, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@DELETE
	@Path("/{siId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> deleteSalesInvoiceMaster(@PathParam("siId") Integer siId){
        try {
        	salesInvoiceService.deleteSalesInvoiceDetails(siId);
        	salesInvoiceService.deleteSalesInvoiceMaster(siId);
        	return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
	@GET
    public Response<?> getSalesInvoiceMaster(@QueryParam("siId") Optional<Integer> siId,
					    	   @QueryParam("siNo") Optional<String> siNo,				   
					    	   @QueryParam("siDate") Optional<String> siDate){
        try{
        	List<SalesInvoiceMaster> listSalesInvoiceMaster = new ArrayList<SalesInvoiceMaster>();
			
			String query = " WHERE si.siId IS NOT NULL";
			if(siId.isPresent())
				query = query + " AND si.siId = " + siId.get();
			if(siNo.isPresent())
				query = query + " AND si.siNo = '" + siNo.get() + "'";
			if(siDate.isPresent())
				query = query + " AND si.siDate = '" + siDate.get() + "'";				
			
			listSalesInvoiceMaster.addAll(salesInvoiceService.getSalesInvoiceMaster(query));
			return Response.ok(Status.SUCCESS.getStatus(), listSalesInvoiceMaster, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }
    }
	
}
