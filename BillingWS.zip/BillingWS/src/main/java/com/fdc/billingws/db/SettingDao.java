/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fdc.billingws.db;

import com.fdc.billingws.dto.Setting;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;

@RegisterMapperFactory(BeanMapperFactory.class)
public interface SettingDao {
        
    @SqlUpdate("INSERT INTO tblSetting (siVatRate,siDueDays,siPrefix,siSuffix,siFillChar,siBodyLength,siStartNo,siEndNo,"
            + "piVatRate,piDueDays,piPrefix,piSuffix,piFillChar,piBodyLength,piStartNo,piEndNo) "
            + "VALUES(:siVatRate,:siDueDays,:siPrefix,:siSuffix,:siFillChar,:siBodyLength,:siStartNo,:siEndNo,:piVatRate,:piDueDays,"
            + ":piPrefix,:piSuffix,:piFillChar,:piBodyLength,:piStartNo,:piEndNo) ")
    public void addSetting(@BindBean Setting setting);

    @SqlUpdate("DELETE FROM tblSetting")
    public void deleteSetting();

    @SqlQuery("SELECT * FROM tblSetting")
    public Setting getSetting();  
}
