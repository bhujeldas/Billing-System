package com.fdc.billingws.db;

import java.sql.ResultSet;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import com.fdc.billingws.dto.Party;
import com.fdc.billingws.dto.SalesInvoiceMaster;
import com.fdc.billingws.dto.User;

public class SalesInvoiceMasterMapper implements ResultSetMapper<SalesInvoiceMaster> {
	
	public SalesInvoiceMaster map(int index, ResultSet ruleset, StatementContext ctx)  {
		
		SalesInvoiceMaster salesInvoiceMaster = new SalesInvoiceMaster();
		try {
			
			Party party = null;
			User user = null;
			salesInvoiceMaster.setSiId(Integer.parseInt(ruleset.getString("siId")));
			salesInvoiceMaster.setSiNo(ruleset.getString("siNo"));
			salesInvoiceMaster.setSiDate(ruleset.getString("siDate"));
			if (null != ruleset.getString("dueDate")){
				salesInvoiceMaster.setDueDate(ruleset.getString("dueDate"));
			}		
			if (null != ruleset.getString("partyId")){
				salesInvoiceMaster.setPartyId(Integer.parseInt(ruleset.getString("partyId")));
				party = new Party();
				party.setId(Integer.parseInt(ruleset.getString("partyId")));
				party.setType(Integer.parseInt(ruleset.getString("pType")));
				party.setAlias(ruleset.getString("pAlias"));
				party.setName(ruleset.getString("pName"));
				party.setStreetAddress(ruleset.getString("pStreetAddress"));
				party.setCity(ruleset.getString("pCity"));
				party.setState(ruleset.getString("pState"));
				party.setCountry(ruleset.getString("pCountry"));
				party.setPhoneNo(ruleset.getString("pPhoneNo"));
				party.setContactPerson(ruleset.getString("pContactPerson"));
				party.setMobileNo(ruleset.getString("pMobileNo"));
				party.setContactEmail(ruleset.getString("pContactEmail"));
				party.setRemarks(ruleset.getString("pRemarks"));
			}
			salesInvoiceMaster.setParty(party);
			
			salesInvoiceMaster.setAddress(ruleset.getString("address"));
			salesInvoiceMaster.setPanNo(ruleset.getString("panNo"));
			salesInvoiceMaster.setRemarks(ruleset.getString("remarks"));
			salesInvoiceMaster.setTotalAmount(Float.parseFloat(ruleset.getString("totalAmount")));
			salesInvoiceMaster.setDisRate(Float.parseFloat(ruleset.getString("disRate")));
			salesInvoiceMaster.setDisAmount(Float.parseFloat(ruleset.getString("disAmount")));
			salesInvoiceMaster.setTaxableAmount(Float.parseFloat(ruleset.getString("taxableAmount")));
			salesInvoiceMaster.setTaxRate(Float.parseFloat(ruleset.getString("taxRate")));
			salesInvoiceMaster.setTaxAmount(Float.parseFloat(ruleset.getString("taxAmount")));
			salesInvoiceMaster.setNetAmount(Float.parseFloat(ruleset.getString("netAmount")));
			salesInvoiceMaster.setPrintCount(Integer.parseInt(ruleset.getString("printCount")));
			salesInvoiceMaster.setCanceled(Integer.parseInt(ruleset.getString("canceled")));
			if (null != ruleset.getString("userId")){
				salesInvoiceMaster.setUserId(Integer.parseInt(ruleset.getString("userId")));
				user = new User();
				user.setId(Integer.parseInt(ruleset.getString("userId")));
				user.setUserName(ruleset.getString("userName"));
				user.setLoginName(ruleset.getString("loginName"));
				user.setPassword(ruleset.getString("password"));
				user.setUgId(Integer.parseInt(ruleset.getString("ugId")));
				user.setRemarks(ruleset.getString("uRemarks"));
			}
			salesInvoiceMaster.setUser(user);
			salesInvoiceMaster.setEntryDate(ruleset.getString("entryDate"));
					
	
		} catch (Exception e) {
			System.out.println("error on sales invoice master mapper " + e.getMessage());
			// TODO: handle exception
		}
		return salesInvoiceMaster;
	}
}
