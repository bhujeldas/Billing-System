package com.fdc.billingws.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.skife.jdbi.v2.StatementContext;
import org.skife.jdbi.v2.tweak.ResultSetMapper;

import com.fdc.billingws.dto.User;
import com.fdc.billingws.dto.UserGroup;

public class UserMapper implements ResultSetMapper<User>{

	public User map(int index, ResultSet ruleset, StatementContext ctx) throws SQLException {
		User user = new User();
		UserGroup userGroup = null;
		
		user.setId(Integer.parseInt(ruleset.getString("id")));
		user.setUserName(ruleset.getString("userName"));
		user.setLoginName(ruleset.getString("loginName"));
		user.setPassword(ruleset.getString("password"));
		if (null != ruleset.getString("ugId")){
			user.setUgId(Integer.parseInt(ruleset.getString("ugId")));
			
			userGroup = new UserGroup();
			userGroup.setId(Integer.parseInt(ruleset.getString("ugId")));
			userGroup.setAlias(ruleset.getString("ugAlias"));
			userGroup.setName(ruleset.getString("ugName"));
			userGroup.setRemarks(ruleset.getString("ugRemarks"));
		}
		user.setUserGroup(userGroup);
		user.setRemarks(ruleset.getString("remarks"));
		return user;	
	}

}
