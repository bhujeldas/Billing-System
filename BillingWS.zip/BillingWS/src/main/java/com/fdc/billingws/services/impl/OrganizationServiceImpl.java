package com.fdc.billingws.services.impl;

import com.fdc.billingws.db.OrganizationDao;
import com.fdc.billingws.dto.Organization;
import com.fdc.billingws.services.IBillingWS;
import com.fdc.billingws.services.IOrganizationService;

public class OrganizationServiceImpl implements IOrganizationService {

	IBillingWS billingWS = null;
	
	public OrganizationServiceImpl(IBillingWS billingWS) {
		this.billingWS = billingWS;
	}

	public Organization addOrganization(Organization organization) {
		OrganizationDao dao = billingWS.getDao(OrganizationDao.class);
		dao.addOrganization(organization);
		return organization;
	}

	public void deleteOrganization() {
		OrganizationDao dao = billingWS.getDao(OrganizationDao.class);
		dao.deleteOrganization();
	}

	public Organization getOrganization() {
		OrganizationDao dao = billingWS.getDao(OrganizationDao.class);
		return dao.getOrganization();
	}

}
