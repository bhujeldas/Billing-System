package com.fdc.billingws.dto;

public class Setting {

	private Float siVatRate;
	private Integer siDueDays;
	private String	siPrefix;
	private	String	siSuffix;
	private	String	siFillChar;
	private	Integer	siBodyLength;
	private	Integer	siStartNo;
	private	Integer	siEndNo;
	private	Float	piVatRate;
	private	Integer	piDueDays;
	private	String	piPrefix;
	private	String	piSuffix;
	private	String	piFillChar;
	private	Integer	piBodyLength;
	private	Integer	piStartNo;
	private	Integer	piEndNo;
	
	public Float getSiVatRate() {
		return siVatRate;
	}
	public void setSiVatRate(Float siVatRate) {
		this.siVatRate = siVatRate;
	}
	public Integer getSiDueDays() {
		return siDueDays;
	}
	public void setSiDueDays(Integer siDueDays) {
		this.siDueDays = siDueDays;
	}
	public String getSiPrefix() {
		return siPrefix;
	}
	public void setSiPrefix(String siPrefix) {
		this.siPrefix = siPrefix;
	}
	public String getSiSuffix() {
		return siSuffix;
	}
	public void setSiSuffix(String siSuffix) {
		this.siSuffix = siSuffix;
	}
	public String getSiFillChar() {
		return siFillChar;
	}
	public void setSiFillChar(String siFillChar) {
		this.siFillChar = siFillChar;
	}
	public Integer getSiBodyLength() {
		return siBodyLength;
	}
	public void setSiBodyLength(Integer siBodyLength) {
		this.siBodyLength = siBodyLength;
	}
	public Integer getSiStartNo() {
		return siStartNo;
	}
	public void setSiStartNo(Integer siStartNo) {
		this.siStartNo = siStartNo;
	}
	public Integer getSiEndNo() {
		return siEndNo;
	}
	public void setSiEndNo(Integer siEndNo) {
		this.siEndNo = siEndNo;
	}
	public Float getPiVatRate() {
		return piVatRate;
	}
	public void setPiVatRate(Float piVatRate) {
		this.piVatRate = piVatRate;
	}
	public Integer getPiDueDays() {
		return piDueDays;
	}
	public void setPiDueDays(Integer piDueDays) {
		this.piDueDays = piDueDays;
	}
	public String getPiPrefix() {
		return piPrefix;
	}
	public void setPiPrefix(String piPrefix) {
		this.piPrefix = piPrefix;
	}
	public String getPiSuffix() {
		return piSuffix;
	}
	public void setPiSuffix(String piSuffix) {
		this.piSuffix = piSuffix;
	}
	public String getPiFillChar() {
		return piFillChar;
	}
	public void setPiFillChar(String piFillChar) {
		this.piFillChar = piFillChar;
	}
	public Integer getPiBodyLength() {
		return piBodyLength;
	}
	public void setPiBodyLength(Integer piBodyLength) {
		this.piBodyLength = piBodyLength;
	}
	public Integer getPiStartNo() {
		return piStartNo;
	}
	public void setPiStartNo(Integer piStartNo) {
		this.piStartNo = piStartNo;
	}
	public Integer getPiEndNo() {
		return piEndNo;
	}
	public void setPiEndNo(Integer piEndNo) {
		this.piEndNo = piEndNo;
	}
}
