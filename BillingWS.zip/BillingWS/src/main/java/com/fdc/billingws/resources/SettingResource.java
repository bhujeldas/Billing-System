package com.fdc.billingws.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.fdc.billingws.dto.Response;
import com.fdc.billingws.dto.Setting;
import com.fdc.billingws.general.Messages;
import com.fdc.billingws.general.Status;
import com.fdc.billingws.services.ISettingService;

@Path("/billingws/Setting")
@Produces(MediaType.APPLICATION_JSON)

public class SettingResource {

	final static Logger logger = Logger.getLogger(SettingResource.class);
	
	ISettingService settingService = null;
	
    public SettingResource(ISettingService settingService) {
		this.settingService = settingService;
	}

	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response<?> addSetting(Setting setting){
        try {			
        	settingService.deleteSetting();
        	settingService.addSetting(setting);
        	return Response.ok(Status.SUCCESS.getStatus(), setting, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
            logger.info(e.getMessage());
            return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
    
    @DELETE
    public Response<?> deleteSetting(){
        try {			
			settingService.deleteSetting();
			return Response.ok(Status.SUCCESS.getStatus(), null, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }		
    }
	
    @GET
    public Response<?> getSetting(){
        try{
			Setting setting = settingService.getSetting();
			return Response.ok(Status.SUCCESS.getStatus(), setting, Messages.SUCCESS.getMessage());
        } catch (Exception e) {
			logger.info(e.getMessage());
			return Response.error(Messages.ERROR.getMessage(), Status.ERROR.getStatus());
        }
    }
}
