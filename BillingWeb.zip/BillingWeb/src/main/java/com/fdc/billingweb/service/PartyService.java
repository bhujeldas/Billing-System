package com.fdc.billingweb.service;

import java.util.List;

import com.fdc.billingweb.dto.Party;
import com.fdc.billingweb.dto.Response;

public interface PartyService {

	Response<Party> addParty(Party party);
	Response<Party> updateParty(Integer id,Party party);
	Response<Party> deleteParty(Integer id);
	public Response<List<Party>> getParty(String url);
	
}
