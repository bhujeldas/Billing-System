package com.fdc.billingweb.service;

import java.util.List;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.Uom;

public interface UomService {
	
	Response<Uom> addUom(Uom uom);
	Response<Uom> updateUom(Integer id,Uom uom);
	Response<Uom> deleteUom(Integer id);
	public Response<List<Uom>> getUom(String url);

}
