package com.fdc.billingweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.Uom;
import com.fdc.billingweb.general.Messages;
import com.fdc.billingweb.general.Status;
import com.fdc.billingweb.service.UomService;

@Controller
@RequestMapping("/uom")
public class UomController {
	private static final Logger logger = LoggerFactory.getLogger(UomController.class);
	
	@Autowired
	UomService uomService;
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String uomHome(HttpServletRequest request, Model model) {
		String pageNo = "1";
		if (request.getParameter("pageNo") != null){
			pageNo= request.getParameter("pageNo");	
		}		
		Response<List<Uom>> response = uomService.getUom("?orderBy=alias&rowCount=7&pageNo=" + pageNo);
		model.addAttribute("uomList", response.getData());
		model.addAttribute("beginIndex", response.getStartNo());
        model.addAttribute("endIndex", response.getEndNo());
        model.addAttribute("currentIndex", response.getCurrentNo());
		return "uomList";
	}
	
	@ResponseBody
    @RequestMapping(value = "/uomPaging", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<List<Uom>> uomPaging(@RequestParam("pageNo") Integer pageNo) {
    	Response<List<Uom>> response = uomService.getUom("?orderBy=alias&rowCount=7&pageNo=" + pageNo);
        return response;
    }    
	
	@RequestMapping(value = "addUom", method = RequestMethod.GET)
	public String addUom(HttpServletRequest request) {
		return "uom";
	}
	
	@RequestMapping(value = "editUom", method = RequestMethod.GET)
	public String editUom(@RequestParam("id") Integer id,
						  @RequestParam("pageNo") Integer pageNo,Model model) {
		if (null != id && id != 0){
			Response<List<Uom>> response = uomService.getUom("?id=" + id);
			if (response.getData().size() > 0 ){
				model.addAttribute("uom", response.getData().get(0));	
				model.addAttribute("pageNo", pageNo);
			}			
		}
		return "uom";
	}
	
	/*@RequestMapping(value = "/uomUpdate", method = RequestMethod.POST)
	public String uomUpdate(HttpServletRequest request, Model model) {
		String id = request.getParameter("id");
		String alias = request.getParameter("alias");
		String name = request.getParameter("name");
		String remarks = request.getParameter("remarks");
		
		Uom uom = new Uom();
		if (null != id && !id.isEmpty()){
			uom.setId(Integer.parseInt(id));	
		}		
		uom.setAlias(alias);
		uom.setName(name);
		uom.setRemarks(remarks);
		
		Response<Uom> response = null;
		if (null != id && !id.isEmpty()){
			response = uomService.updateUom(Integer.parseInt(id),uom);
			if (null != response){
				if (response.getStatus() == Status.SUCCESS.getStatus()){
	        		model.addAttribute("msg","Uom updated successfully.");
	        	}else{
	        		model.addAttribute("msg",response.getMessage());
	        	}	
			}else{
				model.addAttribute("msg","error occured");
				logger.info("error occured in uom edit");
			}        	
        }else{
        	response = uomService.addUom(uom);
        	if (null != response){
	        	if (response.getStatus() == Status.SUCCESS.getStatus()){
	        		model.addAttribute("msg","Uom successfully add.");
	        	}else{
	        		model.addAttribute("msg",response.getMessage());
	        	}
	        }else{
				model.addAttribute("msg","error occured");
				logger.info("error occured in uom edit");
			}        	
        }
     	model.addAttribute("uom",new Uom());
		return "uom";
	}*/
	
	@ResponseBody
    @RequestMapping(value = "updateUom", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Uom> updateUom(Model model,
							@RequestParam(value = "id", required = false) Integer id,
				            @RequestParam(value = "alias", required = false) String alias,
				            @RequestParam(value = "name", required = false) String name,
				            @RequestParam(value = "remarks", required = false) String remarks,
				            HttpServletRequest request) {
		Uom uom = new Uom();
		if (null != id ){
			uom.setId(id);	
		}		
		uom.setAlias(alias);
		uom.setName(name);
		uom.setRemarks(remarks);
		
		Response<Uom> response = null;
		if (null != id){
			response = uomService.updateUom(id,uom);
			if (null == response){
				response = new Response<Uom>();
				response.setMessage(Messages.ERROR.getMessage());
				logger.info("error occured in uom edit");
			}        	
        }else{
        	response = uomService.addUom(uom);
        	if (null == response){
				response = new Response<Uom>();
				response.setMessage(Messages.ERROR.getMessage());
				logger.info("error occured in uom add");
			}        	
        }
		return response;
	}
	
	@ResponseBody
    @RequestMapping(value = "deleteUom", method = RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Uom> deleteUom(@RequestParam("id") Integer id) {
		Response<Uom> response = null;
		if (null != id && id != 0){
			response = uomService.deleteUom(id);
			if (null == response){
				logger.info("error occured in uom edit");
				response = new Response<Uom>();
				response.setMessage(Messages.ERROR.getMessage());
				response.setStatus(Status.ERROR.getStatus());
			}
		}else{
			logger.info("no id to delete record");
			response = new Response<Uom>();
			response.setMessage(Messages.ERROR.getMessage());
			response.setStatus(Status.ERROR.getStatus());
		}
		return response;
	}    
}
