package com.fdc.billingweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fdc.billingweb.dto.Party;
import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.general.Messages;
import com.fdc.billingweb.general.Status;
import com.fdc.billingweb.service.PartyService;

@Controller
@RequestMapping("/party")
public class PartyController {
	
private static final Logger logger = LoggerFactory.getLogger(UomController.class);
	
	@Autowired
	PartyService partyService;
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String partyHome(HttpServletRequest request, Model model) {
		String pageNo = "1";
		if (request.getParameter("pageNo") != null){
			pageNo= request.getParameter("pageNo");	
		}		
		Response<List<Party>> response = partyService.getParty("?orderBy=alias&rowCount=7&pageNo=" + pageNo);
		model.addAttribute("partyList", response.getData());
		model.addAttribute("beginIndex", response.getStartNo());
        model.addAttribute("endIndex", response.getEndNo());
        model.addAttribute("currentIndex", response.getCurrentNo());
		return "partyList";
	}
	
	@ResponseBody
    @RequestMapping(value = "/partyPaging", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<List<Party>> partyPaging(@RequestParam("pageNo") Integer pageNo) {
    	Response<List<Party>> response = partyService.getParty("?orderBy=alias&rowCount=7&pageNo=" + pageNo);
        return response;
    }    
	
	@ResponseBody
    @RequestMapping(value = "/partyAutoComplete", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Party> partyAutoComplete(@RequestParam("search") String search) {
		Response<List<Party>> response = partyService.getParty("?type=3&aliasLike=" + search);
        return response.getData();
    } 
	
	@ResponseBody
    @RequestMapping(value = "/partyValidation", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<List<Party>> partyValidation(@RequestParam("type") String type,@RequestParam("alias") String alias) {
    	Response<List<Party>> response = partyService.getParty("?orderBy=alias&type=" + type + "&alias=" + alias);
        return response;
    }
	
	@RequestMapping(value = "addParty", method = RequestMethod.GET)
	public String addParty(HttpServletRequest request,Model model) {
		return "party";
	}
	
	@RequestMapping(value = "editParty", method = RequestMethod.GET)
	public String editParty(@RequestParam("id") Integer id,
						  @RequestParam("pageNo") Integer pageNo,Model model) {
		if (null != id && id != 0){
			Response<List<Party>> response = partyService.getParty("?id=" + id);
			if (response.getData().size() > 0 ){
				model.addAttribute("party", response.getData().get(0));	
				model.addAttribute("pageNo", pageNo);
			}			
		}
		return "party";
	}
	
	@ResponseBody
    @RequestMapping(value = "updateParty", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Party> updateParty(Model model,
							@RequestParam(value = "id", required = false) Integer id,
							@RequestParam(value = "type", required = false) Integer type,
				            @RequestParam(value = "alias", required = false) String alias,
				            @RequestParam(value = "name", required = false) String name,
				            @RequestParam(value = "streetAddress", required = false) String streetAddress,
				            @RequestParam(value = "city", required = false) String city,
				            @RequestParam(value = "state", required = false) String state,
				            @RequestParam(value = "country", required = false) String country,
				            @RequestParam(value = "phoneNo", required = false) String phoneNo,
				            @RequestParam(value = "contactPerson", required = false) String contactPerson,
				            @RequestParam(value = "mobileNo", required = false) String mobileNo,
				            @RequestParam(value = "contactEmail", required = false) String contactEmail,
				            @RequestParam(value = "remarks", required = false) String remarks,
				            HttpServletRequest request) {
		Party party = new Party();
		if (null != id ){
			party.setId(id);	
		}		
		party.setType(type);
		party.setAlias(alias);
		party.setName(name);
		party.setStreetAddress(streetAddress);
		party.setCity(city);
		party.setState(state);
		party.setCountry(country);
		party.setPhoneNo(phoneNo);
		party.setContactPerson(contactPerson);
		party.setMobileNo(mobileNo);
		party.setContactEmail(contactEmail);
		party.setRemarks(remarks);
		
		Response<Party> response = null;
		if (null != id){
			response = partyService.updateParty(id,party);
			if (null == response){
				response = new Response<Party>();
				response.setMessage(Messages.ERROR.getMessage());
				logger.info("error occured in party edit");
			}        	
        }else{
        	response = partyService.addParty(party);
        	if (null == response){
				response = new Response<Party>();
				response.setMessage(Messages.ERROR.getMessage());
				logger.info("error occured in party add");
			}        	
        }
		return response;
	}
	
	@ResponseBody
    @RequestMapping(value = "deleteParty", method = RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Party> deleteParty(@RequestParam("id") Integer id) {
		Response<Party> response = null;
		if (null != id && id != 0){
			response = partyService.deleteParty(id);
			if (null == response){
				logger.info("error occured in Party delete");
				response = new Response<Party>();
				response.setMessage(Messages.ERROR.getMessage());
				response.setStatus(Status.ERROR.getStatus());
			}
		}else{
			logger.info("no id to delete record");
			response = new Response<Party>();
			response.setMessage(Messages.ERROR.getMessage());
			response.setStatus(Status.ERROR.getStatus());
		}
		return response;
	}

}
