package com.fdc.billingweb.general;

public enum Messages {
	USER_SUCCESS("User found!"),
	USER_FAIL("User not found!"),
	INVALID_LOGIN("User or password does not mathch."),
	VALID_DATE("Valid Data."),
	INVALID_DATA("Invalid Data."),
	SUCCESS("Success"),
	ERROR("Error"),
	NOT_FOUND("Not Found"),
	ALIAS_SHOULD_NOT_BE_BLANK("Alias should not be blank"),
	NAME_SHOULD_NOT_BE_BLANK("Name should not be blank"),
	ALIAS_ALREADY_EXISTS("Alias already exists"),
	NAME_ALREADY_EXISTS("Name already exits"),
	ALIAS_DOES_NOT_EXIST("Alias does not Exists"),
	NAME_DOES_NOT_EXIST("Name does not exits"),
	REFNO_SHOULD_NOT_BE_BLANK("Ref No. should be blank"),
	REFNO_ALREADY_EXISTS("Ref No. already exists");
	private String message;
	 Messages(String msg){
		this.setMessage(msg);
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
