package com.fdc.billingweb.dto;

import java.util.List;

public class SalesInvoiceMaster {

	private Integer	siId;
	private String siNo;
	private	String siDate;
	private	String dueDate;
	private	Integer partyId;
	private Party party;
	private	String address;
	private	String panNo;
	private	String remarks;
	private	Float totalAmount;
	private	Float disRate;
	private	Float disAmount;
	private	Float taxableAmount;
	private	Float taxRate;
	private	Float taxAmount;
	private	Float netAmount;
	private	Integer	printCount;
	private	Integer	canceled;
	private Integer userId;
	private	User user;
	private	String entryDate;
	private	List<SalesInvoiceDetails> salesInvoiceDetails;

	public Integer getSiId() {
		return siId;
	}
	public void setSiId(Integer siId) {
		this.siId = siId;
	}
	public String getSiNo() {
		return siNo;
	}
	public void setSiNo(String siNo) {
		this.siNo = siNo;
	}
	public String getSiDate() {
		return siDate;
	}
	public void setSiDate(String siDate) {
		this.siDate = siDate;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public Integer getPartyId() {
		return partyId;
	}
	public void setPartyId(Integer partyId) {
		this.partyId = partyId;
	}
	public Party getParty() {
		return party;
	}
	public void setParty(Party party) {
		this.party = party;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Float totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Float getDisRate() {
		return disRate;
	}
	public void setDisRate(Float disRate) {
		this.disRate = disRate;
	}
	public Float getDisAmount() {
		return disAmount;
	}
	public void setDisAmount(Float disAmount) {
		this.disAmount = disAmount;
	}
	public Float getTaxableAmount() {
		return taxableAmount;
	}
	public void setTaxableAmount(Float taxableAmount) {
		this.taxableAmount = taxableAmount;
	}
	public Float getTaxRate() {
		return taxRate;
	}
	public void setTaxRate(Float taxRate) {
		this.taxRate = taxRate;
	}
	public Float getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(Float taxAmount) {
		this.taxAmount = taxAmount;
	}
	public Float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Float netAmount) {
		this.netAmount = netAmount;
	}
	public Integer getPrintCount() {
		return printCount;
	}
	public void setPrintCount(Integer printCount) {
		this.printCount = printCount;
	}
	public Integer getCanceled() {
		return canceled;
	}
	public void setCanceled(Integer canceled) {
		this.canceled = canceled;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public List<SalesInvoiceDetails> getSalesInvoiceDetails() {
		return salesInvoiceDetails;
	}
	public void setSalesInvoiceDetails(List<SalesInvoiceDetails> salesInvoiceDetails) {
		this.salesInvoiceDetails = salesInvoiceDetails;
	}
	
}
