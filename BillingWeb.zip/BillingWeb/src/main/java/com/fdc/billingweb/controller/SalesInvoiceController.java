package com.fdc.billingweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fdc.billingweb.dto.Item;
import com.fdc.billingweb.dto.Party;
import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.SalesInvoiceMaster;
import com.fdc.billingweb.dto.Uom;
import com.fdc.billingweb.general.Messages;
import com.fdc.billingweb.general.Status;
import com.fdc.billingweb.service.ItemService;
import com.fdc.billingweb.service.PartyService;
import com.fdc.billingweb.service.SalesInvoiceService;
import com.fdc.billingweb.service.UomService;
import com.fdc.billingweb.service.impl.SalesInvoiceServiceImpl;

@Controller
@RequestMapping("/salesInvoice")
public class SalesInvoiceController {

private static final Logger logger = LoggerFactory.getLogger(SalesInvoiceController.class);
	
	@Autowired
	ItemService itemService;
	@Autowired
	PartyService partyService;
	@Autowired
	UomService uomService;
	@Autowired
	SalesInvoiceService salesInvoiceService;
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String itemHome(HttpServletRequest request, Model model) {
		String pageNo = "1";
		if (request.getParameter("pageNo") != null){
			pageNo= request.getParameter("pageNo");	
		}		
		Response<List<SalesInvoiceMaster>> response = salesInvoiceService.getSalesInvoiceMaster("");
		model.addAttribute("salesInvoiceList", response.getData());
		model.addAttribute("beginIndex", response.getStartNo());
        model.addAttribute("endIndex", response.getEndNo());
        model.addAttribute("currentIndex", response.getCurrentNo());
		return "salesInvoiceList";
	}
	
	@ResponseBody
    @RequestMapping(value = "/salesInvoicePaging", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<List<SalesInvoiceMaster>> salesInvoicePaging(@RequestParam("pageNo") Integer pageNo) {
    	Response<List<SalesInvoiceMaster>> response = salesInvoiceService.getSalesInvoiceMaster("");
        return response;
    }    
	
	@RequestMapping(value = "addSalesInvoiceMaster", method = RequestMethod.GET)
	public String addItem(HttpServletRequest request,Model model) {
		System.out.println("Inside Add Sales Invoice Master");
		Response<List<Party>> party = null;
		party = partyService.getParty("?type=3");
		if(null != party ){
			model.addAttribute("partyList", party.getData());	
		}else{
			model.addAttribute("partyList", null);
		}
		Response<List<Item>> item = null;
		item = itemService.getItem("");
		if(null != item ){
			model.addAttribute("itemList", item.getData());	
		}else{
			model.addAttribute("itemList", null);
		}
		return "salesInvoice";
	}
	
	@RequestMapping(value = "editItem", method = RequestMethod.GET)
	public String editUom(@RequestParam("id") Integer id,
						  @RequestParam("pageNo") Integer pageNo,Model model) {
		if (null != id && id != 0){
			Response<List<Item>> response = itemService.getItem("?id=" + id);
			if (response.getData().size() > 0 ){
				Response<List<Uom>> uom = null;
				uom = uomService.getUom("");
				if(null != uom ){
					model.addAttribute("uomList", uom.getData());	
				}else{
					model.addAttribute("uomList", null);
				}
				model.addAttribute("item", response.getData().get(0));	
				model.addAttribute("pageNo", pageNo);
			}			
		}
		return "item";
	}
	
	@ResponseBody
    @RequestMapping(value = "updateItem", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public Response<Item> updateItem(Model model,
							@RequestParam(value = "id", required = false) Integer id,
				            @RequestParam(value = "alias", required = false) String alias,
				            @RequestParam(value = "name", required = false) String name,
				            @RequestParam(value = "uId", required = false) Integer uId,
				            @RequestParam(value = "sellingRate", required = false) Float sellingRate,
				            @RequestParam(value = "buyingRate", required = false) Float buyingRate,
				            @RequestParam(value = "remarks", required = false) String remarks,
				            HttpServletRequest request) {
		Item item = new Item();
		if (null != id ){
			item.setId(id);	
		}		
		item.setAlias(alias);
		item.setName(name);
		System.out.println("uId " + uId);
		if (uId > 0){
			item.setuId(uId);	
		}else{
			item.setuId(null);
		}
		item.setSellingRate(sellingRate);
		item.setBuyingRate(buyingRate);
		item.setRemarks(remarks);
		
		Response<Item> response = null;
		if (null != id){
			response = itemService.updateItem(id,item);
			if (null == response){
				response = new Response<Item>();
				response.setMessage(Messages.ERROR.getMessage());
				logger.info("error occured in item edit");
			}        	
        }else{
        	response = itemService.addItem(item);
        	if (null == response){
				response = new Response<Item>();
				response.setMessage(Messages.ERROR.getMessage());
				logger.info("error occured in item add");
			}        	
        }
		return response;
	}
	
	@ResponseBody
    @RequestMapping(value = "deleteItem", method = RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
    public Response<Item> deleteItem(@RequestParam("id") Integer id) {
		Response<Item> response = null;
		if (null != id && id != 0){
			response = itemService.deleteItem(id);
			if (null == response){
				logger.info("error occured in uom edit");
				response = new Response<Item>();
				response.setMessage(Messages.ERROR.getMessage());
				response.setStatus(Status.ERROR.getStatus());
			}
		}else{
			logger.info("no id to delete record");
			response = new Response<Item>();
			response.setMessage(Messages.ERROR.getMessage());
			response.setStatus(Status.ERROR.getStatus());
		}
		return response;
	}
}
