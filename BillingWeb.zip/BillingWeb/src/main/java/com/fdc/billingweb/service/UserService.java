package com.fdc.billingweb.service;

import com.fdc.billingweb.dto.User;

public interface UserService {

	User addUser(User user);
	User updateUser(User user);
	void deleteUser(Integer id);
	User getUsersByUsername(String userName);
	User getUserById(Integer id);

}
