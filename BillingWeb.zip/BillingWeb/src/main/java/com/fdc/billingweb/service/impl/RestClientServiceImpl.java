package com.fdc.billingweb.service.impl;

import java.io.File;
import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.service.RestClientService;


@SuppressWarnings({"rawtypes"})
@Service
public class RestClientServiceImpl implements RestClientService {

	final static Logger logger = LoggerFactory.getLogger(RestClientServiceImpl.class);

    @Value("${url.webservice}")
    private String webserviceURL;

    public RestClientServiceImpl(){
    }
    
    public RestClientServiceImpl(String url){
    	webserviceURL= url;
    }
    
	@Override
	public Response<?> get(String requestUrl, JavaType responseType) {
		return callGet(requestUrl, responseType);
	}
	
	private Response<?> callGet(String requestUrl, JavaType responseType) {
        HttpClient httpclient = new DefaultHttpClient();
        HttpGet httpGet = null;
        httpGet = new HttpGet(webserviceURL + requestUrl);
        Response response = null;
        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        String responseBody = "";
        try {
            responseBody = httpclient.execute(httpGet, responseHandler);
        } catch (ClientProtocolException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        ObjectMapper jsonParser = new ObjectMapper();
        try {
            response = jsonParser.readValue(responseBody, responseType);
        } catch (JsonParseException e) {
            logger.info(e.getMessage());
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        return response;
    }


	@Override
	public Response<?> postJson(String requestUrl, Object body) {
		return callPost(requestUrl, body);
	}
	
	private Response<?> callPost(String requestUrl, Object body) {
        RestTemplate restTemplate = new RestTemplate();
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = "";
        try {
            requestJson = mapper.writeValueAsString(body);
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
        Response response = restTemplate.postForObject(requestUrl, entity, Response.class);
        return response;
    }

	@Override
	public Response<?> postJson(String requestUrl, Object body, JavaType responseType) {
		return callPost(requestUrl, body, responseType);
	}

	private Response<?> callPost(String requestUrl, Object body, JavaType responseType) {
        RestTemplate restTemplate = new RestTemplate();
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = "";
        try {
            requestJson = mapper.writeValueAsString(body);
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
        String responseBody = restTemplate.postForObject(webserviceURL + requestUrl, entity, String.class);
        Response response = null;
        ObjectMapper jsonParser = new ObjectMapper();
        try {
            response = jsonParser.readValue(responseBody, responseType);
        } catch (Exception e) {
            JavaType responseTypeObj = jsonParser.getTypeFactory().constructParametricType(Response.class,
                    jsonParser.getTypeFactory().constructType(Object.class));
            try {
                response = jsonParser.readValue(responseBody, responseTypeObj);
            } catch (Exception e1) {
                e1.printStackTrace();
                logger.info(e1.getMessage());
            }
            e.printStackTrace();
            logger.info(e.getMessage());
        }
        return response;
    }
	
	@Override
	public Response<?> postMultipart(String requestUrl, String jsonString, String jsonObject, File file,String fileName, JavaType responseType) {
		HttpClient httpclient = new DefaultHttpClient();
        HttpPost httpost = new HttpPost(webserviceURL + requestUrl);
        org.apache.http.HttpEntity entity = null;
        if (file != null) {
            entity = MultipartEntityBuilder
                    .create()
                    .addBinaryBody(jsonObject, jsonString.getBytes(), ContentType.create("application/json"), "file.json")
                    .addBinaryBody("file", file, ContentType.create("application/jpg"), fileName)
                    .build();
        } else {
            entity = MultipartEntityBuilder
                    .create()
                    .addBinaryBody(jsonObject, jsonString.getBytes(), ContentType.create("application/json"), "file.json")
                    .build();
        }
        httpost.setEntity(entity);
        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        String responseBody = "";
        try {
            responseBody = httpclient.execute(httpost, responseHandler);
        } catch (ClientProtocolException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        Response response = null;
        ObjectMapper jsonParser = new ObjectMapper();
        try {
            response = jsonParser.readValue(responseBody, responseType);
        } catch (JsonParseException e) {
            logger.info(e.getMessage());
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        return response;
	}
	
	@Override
	public Response<?> putJson(String requestUrl, Object body, JavaType responseType) {
		return callPut(requestUrl, body, responseType);
	}
	
	private Response<?> callPut(String requestUrl, Object body, JavaType responseType) {
		RestTemplate restTemplate = new RestTemplate();
		ObjectMapper mapper = new ObjectMapper();
		String requestJson = "";
		Response response = null;
        try {
            requestJson = mapper.writeValueAsString(body);
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON); 
	    HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    System.out.println("URL " + webserviceURL );
	    System.out.println("request " + requestUrl);
	    ResponseEntity<String> responseBody = restTemplate.exchange(webserviceURL + requestUrl, HttpMethod.PUT, entity, String.class );
	    try {
            response = mapper.readValue(responseBody.getBody(), responseType);
        } catch (JsonParseException e) {
            logger.info(e.getMessage());
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        return response;
    }

	@Override
	public Response<?> delete(String requestUrl) {
		return callDelete(requestUrl);
	}
	
	private Response<?> callDelete(String requestUrl) {
		RestTemplate restTemplate = new RestTemplate();
		ObjectMapper mapper = new ObjectMapper();
		Response response = null;
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON); 
	    HttpEntity<String> entity = new HttpEntity<String>(headers) ;
	    ResponseEntity<String> responseBody = restTemplate.exchange(webserviceURL + requestUrl, HttpMethod.DELETE, entity, String.class );
	    System.out.println("response " + responseBody);
	    System.out.println("response body " + responseBody.getBody());
	    try {
            response = mapper.readValue(responseBody.getBody(), Response.class);
        } catch (JsonParseException e) {
            logger.info(e.getMessage());
        } catch (JsonMappingException e) {
            logger.info(e.getMessage());
        } catch (IOException e) {
            logger.info(e.getMessage());
        }
        return response;
    }


    
}