package com.fdc.billingweb.security;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.User;
import com.fdc.billingweb.general.Status;
import com.fdc.billingweb.service.RestClientService;
import com.fdc.billingweb.service.impl.RestClientServiceImpl;


@Service
public class CustomUserDetailsService implements UserDetailsService {

    RestClientService restClientService;

    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
    	Properties prop = new Properties();
        InputStream input = null;
        String webserviceURL = "";
        try {
            input = getClass().getClassLoader().getResourceAsStream("config.properties");
            prop.load(input);
            webserviceURL = prop.getProperty("url.webservice");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        UserDetails userDetails = null;        
        User user = null;
        restClientService = new RestClientServiceImpl(webserviceURL);
        String fetchUser = "getUser?userName=" + userName;
        ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class,jsonParser.getTypeFactory().constructParametricType(List.class,User.class));
        Response<List<User>> response = (Response<List<User>>) restClientService.get(fetchUser, responseType);
        if (null != response) {
            if (Status.SUCCESS.getStatus() == response.getStatus()) {
                user = response.getData().get(0);
            }
        }
        int userId = 0;
        if (null != user) {
            try {
                userId = user.getId();
            } catch (Exception e) {
            }
        }
        userDetails = new CustomUserDetails(
                user.getUserName(),
                user.getPassword(),
                true,
                true,
                true,
                true,
                getAuthorities(user.getUserGroup().getName()),
                userId);
        return userDetails;
    }

    private Collection<GrantedAuthority> getAuthorities(String authority) {
        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>(1);
        authList.add(new SimpleGrantedAuthority(authority));
        return authList;
    }

}
