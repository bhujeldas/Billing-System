package com.fdc.billingweb.service.impl;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.User;
import com.fdc.billingweb.general.Status;
import com.fdc.billingweb.general.WebServiceConstants;
import com.fdc.billingweb.service.RestClientService;
import com.fdc.billingweb.service.UserService;

/**
 */

@SuppressWarnings("unchecked")

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    RestClientService restClientService;

	@SuppressWarnings("rawtypes")
	@Override
	public User addUser(User user) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class,jsonParser.getTypeFactory().constructType(User.class));
        Response response = restClientService.postJson(WebServiceConstants.USER, user, responseType);
        if (null != response) {
            if (Status.SUCCESS.getStatus() == response.getStatus()) {
                return (User) response.getData();
            } else {
                System.out.println("error in response");
            }
        } else {
            System.out.println("Response is null in addUsers");
        }
        return null;
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUsersByUsername(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}


}
