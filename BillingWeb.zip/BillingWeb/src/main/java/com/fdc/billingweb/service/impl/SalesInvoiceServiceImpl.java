package com.fdc.billingweb.service.impl;

import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Item;
import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.SalesInvoiceMaster;
import com.fdc.billingweb.general.WebServiceConstants;
import com.fdc.billingweb.service.SalesInvoiceService;
import com.fdc.billingweb.service.RestClientService;

@Service
public class SalesInvoiceServiceImpl implements SalesInvoiceService {

	@Autowired
    RestClientService restClientService;
	
	@Override
	public Response<SalesInvoiceMaster> addSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(SalesInvoiceMaster.class));
        Response<SalesInvoiceMaster> response = (Response<SalesInvoiceMaster>)restClientService.postJson(WebServiceConstants.SALES_INVOICE_MASTER, salesInvoiceMaster, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<SalesInvoiceMaster> updateSalesInvoiceMaster(Integer id, SalesInvoiceMaster salesInvoiceMaster) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(SalesInvoiceMaster.class));
        Response<SalesInvoiceMaster> response = (Response<SalesInvoiceMaster>)restClientService.putJson(WebServiceConstants.SALES_INVOICE_MASTER + "/" + id, salesInvoiceMaster, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<SalesInvoiceMaster> deleteSalesInvoiceMaster(Integer id) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(SalesInvoiceMaster.class));
        Response<SalesInvoiceMaster> response = (Response<SalesInvoiceMaster>)restClientService.delete(WebServiceConstants.SALES_INVOICE_MASTER + "/" + id);        
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<List<SalesInvoiceMaster>> getSalesInvoiceMaster(String url) {
		ObjectMapper jsonParser = new ObjectMapper();
		JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class,jsonParser.getTypeFactory().constructParametricType(List.class,SalesInvoiceMaster.class));
        Response<List<SalesInvoiceMaster>> response = (Response<List<SalesInvoiceMaster>>) restClientService.get(WebServiceConstants.SALES_INVOICE_MASTER + url, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

}
