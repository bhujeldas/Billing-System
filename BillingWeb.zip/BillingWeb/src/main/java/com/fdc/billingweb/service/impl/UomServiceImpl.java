package com.fdc.billingweb.service.impl;

import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.Uom;
import com.fdc.billingweb.general.Status;
import com.fdc.billingweb.general.WebServiceConstants;
import com.fdc.billingweb.service.RestClientService;
import com.fdc.billingweb.service.UomService;


@Service
public class UomServiceImpl implements UomService {

	@Autowired
    RestClientService restClientService;
	
	@Override
	public Response<Uom> addUom(Uom uom) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Uom.class));
        Response<Uom> response = (Response<Uom>)restClientService.postJson(WebServiceConstants.UOM, uom, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<Uom> updateUom(Integer id ,Uom uom) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Uom.class));
        Response<Uom> response = (Response<Uom>)restClientService.putJson(WebServiceConstants.UOM + "/" + id, uom, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<Uom> deleteUom(Integer id) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Uom.class));
        Response<Uom> response = (Response<Uom>)restClientService.delete(WebServiceConstants.UOM + "/" + id);        
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<List<Uom>> getUom(String url) {
		ObjectMapper jsonParser = new ObjectMapper();
		JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class,jsonParser.getTypeFactory().constructParametricType(List.class,Uom.class));
        Response<List<Uom>> response = (Response<List<Uom>>) restClientService.get(WebServiceConstants.UOM + url, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

}
