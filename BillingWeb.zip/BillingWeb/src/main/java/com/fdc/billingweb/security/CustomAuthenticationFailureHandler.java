package com.fdc.billingweb.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fdc.billingweb.dto.Response;

public class CustomAuthenticationFailureHandler  implements AuthenticationFailureHandler{

	private AuthenticationFailureHandler defaultHandler;
	
	public void onAuthenticationFailure(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException auth)
			throws IOException, ServletException {
		String responseData;
    	ObjectMapper mapper = new ObjectMapper();
		
		if ("true".equals(request.getHeader("X-Ajax-call"))) {
			Response response2 = new Response();
    		response2.setStatus(400);
    		response2.setMessage("Failure");
    		responseData = mapper.writeValueAsString(response2);
	        response.getWriter().print(responseData);
	        response.getWriter().flush();
	    } else {
	        defaultHandler.onAuthenticationFailure(request, response, auth);
	    }
	}

}

