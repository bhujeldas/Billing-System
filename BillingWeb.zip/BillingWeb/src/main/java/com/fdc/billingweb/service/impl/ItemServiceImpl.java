package com.fdc.billingweb.service.impl;

import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Item;
import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.general.WebServiceConstants;
import com.fdc.billingweb.service.ItemService;
import com.fdc.billingweb.service.RestClientService;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
    RestClientService restClientService;
	
	@Override
	public Response<Item> addItem(Item item) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Item.class));
        Response<Item> response = (Response<Item>)restClientService.postJson(WebServiceConstants.ITEM, item, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<Item> updateItem(Integer id, Item item) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Item.class));
        Response<Item> response = (Response<Item>)restClientService.putJson(WebServiceConstants.ITEM + "/" + id, item, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<Item> deleteItem(Integer id) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Item.class));
        Response<Item> response = (Response<Item>)restClientService.delete(WebServiceConstants.ITEM + "/" + id);        
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<List<Item>> getItem(String url) {
		ObjectMapper jsonParser = new ObjectMapper();
		JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class,jsonParser.getTypeFactory().constructParametricType(List.class,Item.class));
        Response<List<Item>> response = (Response<List<Item>>) restClientService.get(WebServiceConstants.ITEM + url, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

}
