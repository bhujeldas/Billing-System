package com.fdc.billingweb.service.impl;

import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Party;
import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.general.WebServiceConstants;
import com.fdc.billingweb.service.PartyService;
import com.fdc.billingweb.service.RestClientService;

@Service
public class PartyServiceImpl implements PartyService {
	
	@Autowired
    RestClientService restClientService;

	@Override
	public Response<Party> addParty(Party party) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Party.class));
        Response<Party> response = (Response<Party>)restClientService.postJson(WebServiceConstants.PARTY, party, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<Party> updateParty(Integer id, Party party) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Party.class));
        Response<Party> response = (Response<Party>)restClientService.putJson(WebServiceConstants.PARTY + "/" + id,party, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<Party> deleteParty(Integer id) {
		ObjectMapper jsonParser = new ObjectMapper();
        JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class, jsonParser.getTypeFactory().constructType(Party.class));
        Response<Party> response = (Response<Party>)restClientService.delete(WebServiceConstants.PARTY + "/" + id);        
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

	@Override
	public Response<List<Party>> getParty(String url) {
		ObjectMapper jsonParser = new ObjectMapper();
		JavaType responseType = jsonParser.getTypeFactory().constructParametricType(Response.class,jsonParser.getTypeFactory().constructParametricType(List.class,Party.class));
        Response<List<Party>> response = (Response<List<Party>>) restClientService.get(WebServiceConstants.PARTY + url, responseType);
        if (null != response) {
            return response;
        } else {
            return null;
        }
	}

}
