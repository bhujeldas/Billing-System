package com.fdc.billingweb.service;

import java.util.List;

import com.fdc.billingweb.dto.Response;
import com.fdc.billingweb.dto.SalesInvoiceMaster;

public interface SalesInvoiceService {
	
	Response<SalesInvoiceMaster> addSalesInvoiceMaster(SalesInvoiceMaster salesInvoiceMaster);
	Response<SalesInvoiceMaster> updateSalesInvoiceMaster(Integer id,SalesInvoiceMaster salesInvoiceMaster);
	Response<SalesInvoiceMaster> deleteSalesInvoiceMaster(Integer id);
	public Response<List<SalesInvoiceMaster>> getSalesInvoiceMaster(String url);
	
}
