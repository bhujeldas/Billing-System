package com.fdc.billingweb.dto;

public class Item {

	private Integer	id;
	private String alias;
	private String name;
	private Integer uId;
	private Uom	uom;
	private Float sellingRate;
	private Float buyingRate;
	private String remarks;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getuId() {
		return uId;
	}
	public void setuId(Integer uId) {
		this.uId = uId;
	}
	public Uom getUom() {
		return uom;
	}
	public void setUom(Uom uom) {
		this.uom = uom;
	}
	public Float getSellingRate() {
		return sellingRate;
	}
	public void setSellingRate(Float sellingRate) {
		this.sellingRate = sellingRate;
	}
	public Float getBuyingRate() {
		return buyingRate;
	}
	public void setBuyingRate(Float buyingRate) {
		this.buyingRate = buyingRate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
