package com.fdc.billingweb.service;

import java.util.List;

import com.fdc.billingweb.dto.Item;
import com.fdc.billingweb.dto.Response;

public interface ItemService {

	Response<Item> addItem(Item item);
	Response<Item> updateItem(Integer id,Item item);
	Response<Item> deleteItem(Integer id);
	public Response<List<Item>> getItem(String url);
	
}
