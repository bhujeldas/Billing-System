package com.fdc.billingweb.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fdc.billingweb.security.CustomUserDetails;
import com.fdc.billingweb.service.UserService;

@Controller
public class MainController {

	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
	
	@Autowired
    UserService usersService;
	
	@RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
    public String index(Locale locale,Model model) {
		System.out.println("Inside index");
		model.addAttribute("user", usersService.getUserById(getUserId()));
        return "index";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "index";
    }
    
	public int getUserId(){
		try{
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			UserDetails currentUserDetails = (UserDetails) auth.getPrincipal();
			if (currentUserDetails instanceof CustomUserDetails) {
				CustomUserDetails cstmUser = (CustomUserDetails) currentUserDetails;
				return cstmUser.getuserId();
			}else{
				logger.info("No logged user found in getUserId of MainController as following" );
				return 0;
			}
		}catch (Exception e) {
			logger.info("Error occured in getUserId of MainController as following" );
			logger.info(e.getMessage());
			return 0;
		}
	}
}
