package com.fdc.billingweb.general;

public class WebServiceConstants {

	public static final String USER = "user";
	public static final String UOM = "Uom";
	public static final String ITEM = "Item";    
	public static final String PARTY = "Party";
	public static final String SALES_INVOICE_MASTER = "SalesInvoiceMaster";

}
