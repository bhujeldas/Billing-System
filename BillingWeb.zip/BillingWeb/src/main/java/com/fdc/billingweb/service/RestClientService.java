package com.fdc.billingweb.service;

import java.io.File;

import org.codehaus.jackson.type.JavaType;
import org.springframework.stereotype.Service;

import com.fdc.billingweb.dto.Response;

@Service
public interface RestClientService {
	public Response<?> get(String requestUrl, JavaType responseType);
	public Response<?> postJson(String requestUrl, Object body);
	public Response<?> postJson(String requestUrl, Object body, JavaType responseType);
	public Response<?> postMultipart(String requestUrl, String jsonString, String jsonObject, File file, String fileName, JavaType responseType);
	public Response<?> putJson(String requestUrl, Object body, JavaType responseType);
	public Response<?> delete(String requestUrl);
}
